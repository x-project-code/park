<?php
session_start();
require_once '../config.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id']) || !isset($_SESSION['is_admin'])) {
    header('Location: login.php');
    exit();
}

$conn = getDBConnection();

// Get revenue statistics
$stats = [];

// 1. Total Revenue (all time)
$result = $conn->query("SELECT COALESCE(SUM(parking_fee), 0) as total FROM vehicles WHERE status = 'checked_out'");
$stats['total_revenue'] = $result->fetch_assoc()['total'];

// 2. Today Revenue
$result = $conn->query("SELECT COALESCE(SUM(parking_fee), 0) as total FROM vehicles WHERE status = 'checked_out' AND DATE(check_out_time) = CURDATE()");
$stats['today_revenue'] = $result->fetch_assoc()['total'];

// 3. This Week Revenue
$result = $conn->query("SELECT COALESCE(SUM(parking_fee), 0) as total FROM vehicles WHERE status = 'checked_out' AND YEARWEEK(check_out_time, 1) = YEARWEEK(CURDATE(), 1)");
$stats['week_revenue'] = $result->fetch_assoc()['total'];

// 4. This Month Revenue
$result = $conn->query("SELECT COALESCE(SUM(parking_fee), 0) as total FROM vehicles WHERE status = 'checked_out' AND MONTH(check_out_time) = MONTH(CURDATE()) AND YEAR(check_out_time) = YEAR(CURDATE())");
$stats['month_revenue'] = $result->fetch_assoc()['total'];

// 5. Yesterday Revenue
$result = $conn->query("SELECT COALESCE(SUM(parking_fee), 0) as total FROM vehicles WHERE status = 'checked_out' AND DATE(check_out_time) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)");
$stats['yesterday_revenue'] = $result->fetch_assoc()['total'];

// 6. Last Week Revenue
$result = $conn->query("SELECT COALESCE(SUM(parking_fee), 0) as total FROM vehicles WHERE status = 'checked_out' AND YEARWEEK(check_out_time, 1) = YEARWEEK(DATE_SUB(CURDATE(), INTERVAL 1 WEEK), 1)");
$stats['last_week_revenue'] = $result->fetch_assoc()['total'];

// 7. Last Month Revenue
$result = $conn->query("SELECT COALESCE(SUM(parking_fee), 0) as total FROM vehicles WHERE status = 'checked_out' AND MONTH(check_out_time) = MONTH(DATE_SUB(CURDATE(), INTERVAL 1 MONTH)) AND YEAR(check_out_time) = YEAR(DATE_SUB(CURDATE(), INTERVAL 1 MONTH))");
$stats['last_month_revenue'] = $result->fetch_assoc()['total'];

// Get daily revenue for last 30 days (for chart)
$daily_revenue = [];
$daily_labels = [];
for ($i = 29; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-$i days"));
    $label = date('M d', strtotime("-$i days"));
    
    $result = $conn->query("SELECT COALESCE(SUM(parking_fee), 0) as total 
                           FROM vehicles 
                           WHERE status = 'checked_out' 
                           AND DATE(check_out_time) = '$date'");
    $row = $result->fetch_assoc();
    
    $daily_labels[] = $label;
    $daily_revenue[] = $row['total'];
}

// Get weekly revenue for last 12 weeks (for chart)
$weekly_revenue = [];
$weekly_labels = [];
for ($i = 11; $i >= 0; $i--) {
    $week_start = date('Y-m-d', strtotime("-$i weeks monday"));
    $week_end = date('Y-m-d', strtotime("-$i weeks sunday"));
    $label = date('M d', strtotime("-$i weeks"));
    
    $result = $conn->query("SELECT COALESCE(SUM(parking_fee), 0) as total 
                           FROM vehicles 
                           WHERE status = 'checked_out' 
                           AND DATE(check_out_time) BETWEEN '$week_start' AND '$week_end'");
    $row = $result->fetch_assoc();
    
    $weekly_labels[] = $label;
    $weekly_revenue[] = $row['total'];
}

// Get monthly revenue for last 12 months (for chart)
$monthly_revenue = [];
$monthly_labels = [];

// Get current year and month
$current_year = date('Y');
$current_month = date('m');

for ($i = 11; $i >= 0; $i--) {
    // Calculate year and month properly
    $target_month = $current_month - $i;
    $target_year = $current_year;
    
    // Handle year rollover
    while ($target_month <= 0) {
        $target_month += 12;
        $target_year--;
    }
    
    $month = sprintf('%04d-%02d', $target_year, $target_month);
    $label = date('M Y', mktime(0, 0, 0, $target_month, 1, $target_year));
    
    $result = $conn->query("SELECT COALESCE(SUM(parking_fee), 0) as total 
                           FROM vehicles 
                           WHERE status = 'checked_out' 
                           AND DATE_FORMAT(check_out_time, '%Y-%m') = '$month'");
    $row = $result->fetch_assoc();
    
    $monthly_labels[] = $label;
    $monthly_revenue[] = floatval($row['total']);
}

// Get revenue by vehicle type
$revenue_by_type = [];
$result = $conn->query("SELECT vt.type_name, vt.icon_path, COALESCE(SUM(v.parking_fee), 0) as total_revenue 
                        FROM vehicle_types vt
                        LEFT JOIN vehicles v ON vt.id = v.vehicle_type_id AND v.status = 'checked_out'
                        WHERE vt.status = 'active'
                        GROUP BY vt.id, vt.type_name, vt.icon_path
                        ORDER BY total_revenue DESC");
while ($row = $result->fetch_assoc()) {
    $revenue_by_type[] = $row;
}

// Get revenue by area
$revenue_by_area = [];
$result = $conn->query("SELECT a.area_name, COALESCE(SUM(v.parking_fee), 0) as total_revenue 
                        FROM areas a
                        LEFT JOIN vehicles v ON a.id = v.area_id AND v.status = 'checked_out'
                        WHERE a.status = 'active'
                        GROUP BY a.id, a.area_name
                        ORDER BY total_revenue DESC");
while ($row = $result->fetch_assoc()) {
    $revenue_by_area[] = $row;
}

closeDBConnection($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
    <title>Revenue Breakdown - Admin Panel</title>
    <link rel="stylesheet" href="style.css">
    <?php include 'protection.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <style>
        /* Charts Grid - Mobile Responsive */
        .charts-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(450px, 1fr));
            gap: 30px;
            margin-top: 40px;
        }

        .chart-card {
            min-height: 400px;
        }

        .chart-body {
            position: relative;
            height: 350px;
            padding: 20px;
        }

        .chart-body canvas {
            max-width: 100%;
            height: auto !important;
        }

        /* Tables Grid - Mobile Responsive */
        .tables-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
            gap: 30px;
            margin-top: 40px;
        }

        /* Mobile Responsive */
        @media (max-width: 768px) {
            .charts-grid {
                grid-template-columns: 1fr;
                gap: 20px;
                overflow-x: auto;
                -webkit-overflow-scrolling: touch;
            }

            .chart-card {
                min-width: 100%;
                min-height: 350px;
            }

            .chart-body {
                height: 300px;
                padding: 15px;
                overflow-x: auto;
                -webkit-overflow-scrolling: touch;
            }

            .tables-grid {
                grid-template-columns: 1fr;
                gap: 20px;
            }

            .stats-grid-creative {
                grid-template-columns: 1fr;
                gap: 15px;
            }
        }

        @media (max-width: 480px) {
            .charts-grid {
                grid-template-columns: 1fr;
                gap: 15px;
            }

            .chart-card {
                min-height: 300px;
            }

            .chart-body {
                height: 250px;
                padding: 10px;
            }

            .chart-header h3 {
                font-size: 14px;
            }

            .chart-header svg {
                width: 16px;
                height: 16px;
            }
        }
    </style>
</head>
<body>
    <?php include 'header.php'; ?>
    
    <div class="container">
        <div class="page-header">
            <div>
                <h1>
                    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="vertical-align: middle; margin-right: 10px;">
                        <line x1="12" y1="1" x2="12" y2="23"></line>
                        <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
                    </svg>
                    Revenue Breakdown
                </h1>
                <p style="margin-top: 8px; color: #6c757d;">Complete revenue statistics and trends</p>
            </div>
            <a href="index.php" class="btn btn-secondary">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <line x1="19" y1="12" x2="5" y2="12"></line>
                    <polyline points="12 19 5 12 12 5"></polyline>
                </svg>
                Back to Dashboard
            </a>
        </div>

        <!-- Revenue Statistics Cards -->
        <div class="stats-grid-creative stats-grid-8">
            <!-- Total Revenue -->
            <div class="stat-card-creative stat-card-featured" data-animate="true">
                <div class="featured-overlay"></div>
                <div class="stat-card-header">
                    <div class="stat-icon-creative" style="background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <line x1="12" y1="1" x2="12" y2="23"></line>
                            <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
                        </svg>
                    </div>
                    <span class="stat-badge-premium">💰 All Time</span>
                </div>
                <div class="stat-content">
                    <h2 class="stat-number stat-number-large">Rs. <?php echo number_format($stats['total_revenue'], 2); ?></h2>
                    <p class="stat-label">Total Revenue</p>
                </div>
            </div>

            <!-- Today Revenue -->
            <div class="stat-card-creative" data-animate="true">
                <div class="stat-card-header">
                    <div class="stat-icon-creative" style="background: linear-gradient(135deg, #FF9800 0%, #FF5722 100%);">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="12" cy="12" r="10"></circle>
                            <polyline points="12 6 12 12 16 14"></polyline>
                        </svg>
                    </div>
                    <span class="stat-badge-small">Today</span>
                </div>
                <div class="stat-content">
                    <h2 class="stat-number stat-number-medium">Rs. <?php echo number_format($stats['today_revenue'], 2); ?></h2>
                    <p class="stat-label">Today Revenue</p>
                    <div class="stat-progress">
                        <div class="progress-bar" style="background: linear-gradient(90deg, #FF9800 0%, #FF5722 100%); width: 100%;"></div>
                    </div>
                </div>
            </div>

            <!-- This Week Revenue -->
            <div class="stat-card-creative" data-animate="true">
                <div class="stat-card-header">
                    <div class="stat-icon-creative" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                            <line x1="16" y1="2" x2="16" y2="6"></line>
                            <line x1="8" y1="2" x2="8" y2="6"></line>
                            <line x1="3" y1="10" x2="21" y2="10"></line>
                        </svg>
                    </div>
                    <span class="stat-badge-small">This Week</span>
                </div>
                <div class="stat-content">
                    <h2 class="stat-number stat-number-medium">Rs. <?php echo number_format($stats['week_revenue'], 2); ?></h2>
                    <p class="stat-label">Week Revenue</p>
                    <div class="stat-progress">
                        <div class="progress-bar" style="background: linear-gradient(90deg, #667eea 0%, #764ba2 100%); width: 100%;"></div>
                    </div>
                </div>
            </div>

            <!-- This Month Revenue -->
            <div class="stat-card-creative" data-animate="true">
                <div class="stat-card-header">
                    <div class="stat-icon-creative" style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                            <circle cx="12" cy="10" r="3"></circle>
                        </svg>
                    </div>
                    <span class="stat-badge-small">This Month</span>
                </div>
                <div class="stat-content">
                    <h2 class="stat-number stat-number-medium">Rs. <?php echo number_format($stats['month_revenue'], 2); ?></h2>
                    <p class="stat-label">Month Revenue</p>
                    <div class="stat-progress">
                        <div class="progress-bar" style="background: linear-gradient(90deg, #4facfe 0%, #00f2fe 100%); width: 100%;"></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Charts Section -->
        <div class="charts-grid">
            <!-- Daily Revenue Chart -->
            <div class="chart-card">
                <div class="chart-header">
                    <h3>
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <line x1="18" y1="20" x2="18" y2="10"></line>
                            <line x1="12" y1="20" x2="12" y2="4"></line>
                            <line x1="6" y1="20" x2="6" y2="14"></line>
                        </svg>
                        Daily Revenue (Last 30 Days)
                    </h3>
                </div>
                <div class="chart-body">
                    <canvas id="dailyRevenueChart"></canvas>
                </div>
            </div>

            <!-- Weekly Revenue Chart -->
            <div class="chart-card">
                <div class="chart-header">
                    <h3>
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline>
                        </svg>
                        Weekly Revenue (Last 12 Weeks)
                    </h3>
                </div>
                <div class="chart-body">
                    <canvas id="weeklyRevenueChart"></canvas>
                </div>
            </div>

            <!-- Monthly Revenue Chart -->
            <div class="chart-card">
                <div class="chart-header">
                    <h3>
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M3 3v18h18"></path>
                            <path d="M18 17V9"></path>
                            <path d="M13 17V5"></path>
                            <path d="M8 17v-3"></path>
                        </svg>
                        Monthly Revenue (Last 12 Months)
                    </h3>
                </div>
                <div class="chart-body">
                    <canvas id="monthlyRevenueChart"></canvas>
                </div>
            </div>

            <!-- Revenue by Vehicle Type Chart -->
            <div class="chart-card">
                <div class="chart-header">
                    <h3>
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="12" cy="12" r="10"></circle>
                            <line x1="12" y1="2" x2="12" y2="12"></line>
                            <line x1="12" y1="12" x2="16" y2="16"></line>
                        </svg>
                        Revenue by Vehicle Type
                    </h3>
                </div>
                <div class="chart-body">
                    <canvas id="vehicleTypeRevenueChart"></canvas>
                </div>
            </div>
        </div>

        <!-- Revenue Breakdown Tables -->
        <div class="tables-grid">
            <!-- Revenue by Vehicle Type -->
            <div class="dashboard-card">
                <div class="card-header">
                    <h3>
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <rect x="1" y="3" width="15" height="13"></rect>
                            <polygon points="16 8 20 8 23 11 23 16 16 16 16 8"></polygon>
                            <circle cx="5.5" cy="18.5" r="2.5"></circle>
                            <circle cx="18.5" cy="18.5" r="2.5"></circle>
                        </svg>
                        Revenue by Vehicle Type
                    </h3>
                </div>
                <div class="card-body">
                    <div class="vehicle-type-breakdown">
                        <?php 
                        $total_revenue_all = array_sum(array_column($revenue_by_type, 'total_revenue'));
                        foreach ($revenue_by_type as $type): 
                            $percentage = $total_revenue_all > 0 ? ($type['total_revenue'] / $total_revenue_all) * 100 : 0;
                        ?>
                        <div class="type-breakdown-item" style="background: linear-gradient(135deg, #f5f6fa 0%, #f5f6fa 100%);">
                            <div class="type-breakdown-header">
                                <div class="type-breakdown-info">
                                    <div class="type-breakdown-icon-wrapper">
                                        <img src="../<?php echo htmlspecialchars($type['icon_path']); ?>" 
                                             alt="<?php echo htmlspecialchars($type['type_name']); ?>" 
                                             style="width: 40px; height: 40px;">
                                    </div>
                                    <div class="type-breakdown-title">
                                        <h4 style="color: #43e97b;"><?php echo htmlspecialchars($type['type_name']); ?></h4>
                                        <span class="type-breakdown-count">Rs. <?php echo number_format($type['total_revenue'], 2); ?></span>
                                    </div>
                                </div>
                                <div class="type-breakdown-percentage" style="color: #43e97b;">
                                    <?php echo number_format($percentage, 1); ?>%
                                </div>
                            </div>
                            <div class="type-breakdown-bar">
                                <div class="bar-fill" style="width: <?php echo $percentage; ?>%; background: #43e97b;"></div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <!-- Revenue by Area -->
            <div class="dashboard-card">
                <div class="card-header">
                    <h3>
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                            <circle cx="12" cy="10" r="3"></circle>
                        </svg>
                        Revenue by Area
                    </h3>
                </div>
                <div class="card-body">
                    <div class="vehicle-type-breakdown">
                        <?php 
                        $total_revenue_area = array_sum(array_column($revenue_by_area, 'total_revenue'));
                        foreach ($revenue_by_area as $area): 
                            $percentage = $total_revenue_area > 0 ? ($area['total_revenue'] / $total_revenue_area) * 100 : 0;
                        ?>
                        <div class="type-breakdown-item" style="background: linear-gradient(135deg, #f5f6fa 0%, #f5f6fa 100%);">
                            <div class="type-breakdown-header">
                                <div class="type-breakdown-info">
                                    <div class="type-breakdown-icon-wrapper">
                                        <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#4facfe" stroke-width="2">
                                            <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                                            <circle cx="12" cy="10" r="3"></circle>
                                        </svg>
                                    </div>
                                    <div class="type-breakdown-title">
                                        <h4 style="color: #4facfe;"><?php echo htmlspecialchars($area['area_name']); ?></h4>
                                        <span class="type-breakdown-count">Rs. <?php echo number_format($area['total_revenue'], 2); ?></span>
                                    </div>
                                </div>
                                <div class="type-breakdown-percentage" style="color: #4facfe;">
                                    <?php echo number_format($percentage, 1); ?>%
                                </div>
                            </div>
                            <div class="type-breakdown-bar">
                                <div class="bar-fill" style="width: <?php echo $percentage; ?>%; background: #4facfe;"></div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="script.js"></script>
    <script>
        // Daily Revenue Chart
        const dailyCtx = document.getElementById('dailyRevenueChart').getContext('2d');
        new Chart(dailyCtx, {
            type: 'line',
            data: {
                labels: <?php echo json_encode($daily_labels); ?>,
                datasets: [{
                    label: 'Daily Revenue (Rs.)',
                    data: <?php echo json_encode($daily_revenue); ?>,
                    borderColor: 'rgb(255, 152, 0)',
                    backgroundColor: 'rgba(255, 152, 0, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: true, position: 'top' }
                },
                scales: {
                    y: { beginAtZero: true }
                }
            }
        });

        // Weekly Revenue Chart
        const weeklyCtx = document.getElementById('weeklyRevenueChart').getContext('2d');
        new Chart(weeklyCtx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($weekly_labels); ?>,
                datasets: [{
                    label: 'Weekly Revenue (Rs.)',
                    data: <?php echo json_encode($weekly_revenue); ?>,
                    backgroundColor: 'rgba(102, 126, 234, 0.8)',
                    borderColor: 'rgb(102, 126, 234)',
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: true, position: 'top' }
                },
                scales: {
                    y: { beginAtZero: true }
                }
            }
        });

        // Monthly Revenue Chart
        const monthlyCtx = document.getElementById('monthlyRevenueChart').getContext('2d');
        new Chart(monthlyCtx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($monthly_labels); ?>,
                datasets: [{
                    label: 'Monthly Revenue (Rs.)',
                    data: <?php echo json_encode($monthly_revenue); ?>,
                    backgroundColor: 'rgba(79, 172, 254, 0.8)',
                    borderColor: 'rgb(79, 172, 254)',
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: true, position: 'top' },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return 'Revenue: Rs. ' + context.parsed.y.toLocaleString('en-US', {minimumFractionDigits: 2});
                            }
                        }
                    }
                },
                scales: {
                    y: { 
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return 'Rs. ' + value.toLocaleString();
                            }
                        }
                    },
                    x: {
                        ticks: {
                            maxRotation: 45,
                            minRotation: 45
                        }
                    }
                }
            }
        });

        // Revenue by Vehicle Type Chart (Pie)
        const vehicleTypeCtx = document.getElementById('vehicleTypeRevenueChart').getContext('2d');
        new Chart(vehicleTypeCtx, {
            type: 'doughnut',
            data: {
                labels: <?php echo json_encode(array_column($revenue_by_type, 'type_name')); ?>,
                datasets: [{
                    label: 'Revenue (Rs.)',
                    data: <?php echo json_encode(array_column($revenue_by_type, 'total_revenue')); ?>,
                    backgroundColor: [
                        'rgba(102, 126, 234, 0.8)',
                        'rgba(67, 233, 123, 0.8)',
                        'rgba(255, 152, 0, 0.8)',
                        'rgba(240, 147, 251, 0.8)',
                        'rgba(79, 172, 254, 0.8)'
                    ],
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { 
                        display: true, 
                        position: window.innerWidth <= 768 ? 'bottom' : 'right' 
                    }
                }
            }
        });
    </script>
</body>
</html>


<?php
session_start();
require_once '../config.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id']) || !isset($_SESSION['is_admin'])) {
    header('Location: login.php');
    exit();
}

$conn = getDBConnection();

// Handle status updates
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'update_status' && isset($_POST['warning_id']) && isset($_POST['status'])) {
        $warningId = intval($_POST['warning_id']);
        $status = $conn->real_escape_string($_POST['status']);
        
        $updateSql = "UPDATE vehicle_validation_warnings SET status = '$status' WHERE id = $warningId";
        $conn->query($updateSql);
    }
}

// Get filter parameters
$statusFilter = isset($_GET['status']) ? $_GET['status'] : 'all';
$searchQuery = isset($_GET['search']) ? trim($_GET['search']) : '';

// Build query
$whereClauses = [];
if ($statusFilter !== 'all') {
    $statusFilter = $conn->real_escape_string($statusFilter);
    $whereClauses[] = "vvw.status = '$statusFilter'";
}
if (!empty($searchQuery)) {
    $searchQuery = $conn->real_escape_string($searchQuery);
    $whereClauses[] = "(vvw.vehicle_number LIKE '%$searchQuery%')";
}

$whereSQL = !empty($whereClauses) ? 'WHERE ' . implode(' AND ', $whereClauses) : '';

// Get all validation warnings with user and area information
$sql = "SELECT vvw.*, 
               u.username,
               a.area_name,
               v.status as vehicle_status
        FROM vehicle_validation_warnings vvw
        LEFT JOIN users u ON vvw.user_id = u.id
        LEFT JOIN areas a ON vvw.area_id = a.id
        LEFT JOIN vehicles v ON vvw.vehicle_id = v.id
        $whereSQL
        ORDER BY vvw.created_at DESC";

$result = $conn->query($sql);
$warnings = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $warnings[] = $row;
    }
}

// Get counts for badges
$pendingCountSql = "SELECT COUNT(*) as count FROM vehicle_validation_warnings WHERE status = 'pending'";
$pendingResult = $conn->query($pendingCountSql);
$pendingCount = $pendingResult ? $pendingResult->fetch_assoc()['count'] : 0;

$reviewedCountSql = "SELECT COUNT(*) as count FROM vehicle_validation_warnings WHERE status = 'reviewed'";
$reviewedResult = $conn->query($reviewedCountSql);
$reviewedCount = $reviewedResult ? $reviewedResult->fetch_assoc()['count'] : 0;

$resolvedCountSql = "SELECT COUNT(*) as count FROM vehicle_validation_warnings WHERE status = 'resolved'";
$resolvedResult = $conn->query($resolvedCountSql);
$resolvedCount = $resolvedResult ? $resolvedResult->fetch_assoc()['count'] : 0;

closeDBConnection($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
    <title>Vehicle Validation Warnings - Parking Admin</title>
    <link rel="stylesheet" href="style.css">
    <?php include 'protection.php'; ?>
    <style>
        .warning-card {
            background: white;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 15px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            border-left: 4px solid #ff9800;
        }
        
        .warning-card.reviewed {
            border-left-color: #2196F3;
        }
        
        .warning-card.resolved {
            border-left-color: #4caf50;
            opacity: 0.7;
        }
        
        .warning-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }
        
        .vehicle-number {
            font-size: 20px;
            font-weight: bold;
            color: #1C4D8D;
        }
        
        .warning-badge {
            padding: 4px 12px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
        }
        
        .badge-pending {
            background: #fff3e0;
            color: #e65100;
        }
        
        .badge-reviewed {
            background: #e3f2fd;
            color: #1565c0;
        }
        
        .badge-resolved {
            background: #e8f5e9;
            color: #2e7d32;
        }
        
        .warning-details {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 15px;
        }
        
        .detail-item {
            display: flex;
            flex-direction: column;
        }
        
        .detail-label {
            font-size: 12px;
            color: #666;
            margin-bottom: 4px;
        }
        
        .detail-value {
            font-size: 14px;
            font-weight: 600;
            color: #333;
        }
        
        .type-mismatch {
            background: #fff3e0;
            padding: 10px;
            border-radius: 4px;
            margin: 10px 0;
        }
        
        .type-compare {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 14px;
        }
        
        .type-selected {
            color: #f44336;
            font-weight: 600;
        }
        
        .type-expected {
            color: #4caf50;
            font-weight: 600;
        }
        
        .arrow {
            color: #666;
        }
        
        .warning-actions {
            display: flex;
            gap: 10px;
        }
        
        .btn-action {
            padding: 6px 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 12px;
            font-weight: 600;
            transition: all 0.2s;
        }
        
        .btn-review {
            background: #2196F3;
            color: white;
        }
        
        .btn-review:hover {
            background: #1976D2;
        }
        
        .btn-resolve {
            background: #4caf50;
            color: white;
        }
        
        .btn-resolve:hover {
            background: #388E3C;
        }
        
        .btn-pending {
            background: #ff9800;
            color: white;
        }
        
        .btn-pending:hover {
            background: #F57C00;
        }
        
        .filters {
            background: white;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            align-items: center;
        }
        
        .filter-tabs {
            display: flex;
            gap: 10px;
        }
        
        .filter-tab {
            padding: 8px 16px;
            border: 2px solid #ddd;
            background: white;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            transition: all 0.2s;
            text-decoration: none;
            color: #333;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .filter-tab.active {
            background: #1C4D8D;
            color: white;
            border-color: #1C4D8D;
        }
        
        .filter-count {
            background: rgba(0,0,0,0.1);
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 12px;
        }
        
        .search-box {
            flex: 1;
            min-width: 200px;
        }
        
        .search-input {
            width: 100%;
            padding: 10px;
            border: 2px solid #ddd;
            border-radius: 6px;
            font-size: 14px;
        }
        
        .no-warnings {
            text-align: center;
            padding: 40px;
            color: #666;
        }
        
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .warning-icon {
            width: 24px;
            height: 24px;
            display: inline-block;
        }
    </style>
</head>
<body>
    <?php include 'header.php'; ?>
    
    <div class="container">
        <div class="page-header">
            <h1>
                <svg class="warning-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
                    <line x1="12" y1="9" x2="12" y2="13"></line>
                    <line x1="12" y1="17" x2="12.01" y2="17"></line>
                </svg>
                Vehicle Validation Warnings
            </h1>
        </div>
        
        <div class="filters">
            <!-- <div class="filter-tabs">
                <a href="?status=all<?php echo !empty($searchQuery) ? '&search=' . urlencode($searchQuery) : ''; ?>" 
                   class="filter-tab <?php echo $statusFilter === 'all' ? 'active' : ''; ?>">
                    All
                    <span class="filter-count"><?php echo count($warnings); ?></span>
                </a>
                <a href="?status=pending<?php echo !empty($searchQuery) ? '&search=' . urlencode($searchQuery) : ''; ?>" 
                   class="filter-tab <?php echo $statusFilter === 'pending' ? 'active' : ''; ?>">
                    Pending
                    <span class="filter-count"><?php echo $pendingCount; ?></span>
                </a>
                <a href="?status=reviewed<?php echo !empty($searchQuery) ? '&search=' . urlencode($searchQuery) : ''; ?>" 
                   class="filter-tab <?php echo $statusFilter === 'reviewed' ? 'active' : ''; ?>">
                    Reviewed
                    <span class="filter-count"><?php echo $reviewedCount; ?></span>
                </a>
                <a href="?status=resolved<?php echo !empty($searchQuery) ? '&search=' . urlencode($searchQuery) : ''; ?>" 
                   class="filter-tab <?php echo $statusFilter === 'resolved' ? 'active' : ''; ?>">
                    Resolved
                    <span class="filter-count"><?php echo $resolvedCount; ?></span>
                </a>
            </div> -->
            
            <div class="search-box">
                <form method="GET" action="">
                    <input type="hidden" name="status" value="<?php echo htmlspecialchars($statusFilter); ?>">
                    <input type="text" 
                           name="search" 
                           class="search-input" 
                           placeholder="Search by vehicle number..." 
                           value="<?php echo htmlspecialchars($searchQuery); ?>">
                </form>
            </div>
        </div>
        
        <div class="warnings-list">
            <?php if (count($warnings) > 0): ?>
                <?php foreach ($warnings as $warning): ?>
                    <div class="warning-card <?php echo $warning['status']; ?>">
                        <div class="warning-header">
                            <div class="vehicle-number"><?php echo htmlspecialchars($warning['vehicle_number']); ?></div>
                            <span class="warning-badge badge-<?php echo $warning['status']; ?>">
                                <?php echo $warning['status']; ?>
                            </span>
                        </div>
                        
                        <div class="type-mismatch">
                            <div class="type-compare">
                                <span>Selected: <span class="type-selected"><?php echo htmlspecialchars($warning['selected_type']); ?></span></span>
                                <span class="arrow">→</span>
                                <span>Expected: <span class="type-expected"><?php echo htmlspecialchars($warning['expected_type']); ?></span></span>
                            </div>
                        </div>
                        
                        <div class="warning-details">
                            <div class="detail-item">
                                <div class="detail-label">Check-in Time</div>
                                <div class="detail-value"><?php echo date('Y-m-d H:i', strtotime($warning['check_in_time'])); ?></div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">Area</div>
                                <div class="detail-value"><?php echo htmlspecialchars($warning['area_name']); ?></div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">User</div>
                                <div class="detail-value"><?php echo htmlspecialchars($warning['username']); ?></div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">Vehicle Status</div>
                                <div class="detail-value"><?php echo ucfirst($warning['vehicle_status']); ?></div>
                            </div>
                        </div>
                        
                        <div class="warning-actions">
                            <?php if ($warning['status'] !== 'reviewed'): ?>
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="action" value="update_status">
                                    <input type="hidden" name="warning_id" value="<?php echo $warning['id']; ?>">
                                    <input type="hidden" name="status" value="reviewed">
                                    <button type="submit" class="btn-action btn-review">Mark as Reviewed</button>
                                </form>
                            <?php endif; ?>
                            
                            <?php if ($warning['status'] !== 'resolved'): ?>
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="action" value="update_status">
                                    <input type="hidden" name="warning_id" value="<?php echo $warning['id']; ?>">
                                    <input type="hidden" name="status" value="resolved">
                                    <button type="submit" class="btn-action btn-resolve">Mark as Resolved</button>
                                </form>
                            <?php endif; ?>
                            
                            <?php if ($warning['status'] === 'resolved'): ?>
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="action" value="update_status">
                                    <input type="hidden" name="warning_id" value="<?php echo $warning['id']; ?>">
                                    <input type="hidden" name="status" value="pending">
                                    <button type="submit" class="btn-action btn-pending">Mark as Pending</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="no-warnings">
                    <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="#ccc" stroke-width="2">
                        <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                        <polyline points="22 4 12 14.01 9 11.01"></polyline>
                    </svg>
                    <h3>No warnings found</h3>
                    <p>There are no validation warnings matching your filters.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <script src="script.js"></script>
</body>
</html>


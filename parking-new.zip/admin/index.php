<?php
session_start();
require_once '../config.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id']) || !isset($_SESSION['is_admin'])) {
    header('Location: login.php');
    exit();
}

$conn = getDBConnection();

// Get statistics
$stats = [];

// 1. Total Parking (all time - all vehicles ever registered)
$result = $conn->query("SELECT COUNT(*) as count FROM vehicles");
$stats['total_parking'] = $result->fetch_assoc()['count'];

// 2. Today Parking (checked in today)
$result = $conn->query("SELECT COUNT(*) as count FROM vehicles WHERE DATE(check_in_time) = CURDATE()");
$stats['today_parking'] = $result->fetch_assoc()['count'];

// 3. Current Parking (currently parked right now)
$result = $conn->query("SELECT COUNT(*) as count FROM vehicles WHERE status = 'parked'");
$stats['current_parking'] = $result->fetch_assoc()['count'];

// 4. Today Checkout (checked out today)
$result = $conn->query("SELECT COUNT(*) as count FROM vehicles WHERE status = 'checked_out' AND DATE(check_out_time) = CURDATE()");
$stats['today_checkout'] = $result->fetch_assoc()['count'];

// 5. Total Revenue (all time)
$result = $conn->query("SELECT COALESCE(SUM(parking_fee), 0) as total FROM vehicles WHERE status = 'checked_out'");
$stats['total_revenue'] = $result->fetch_assoc()['total'];

// 6. Month Revenue (this month)
$result = $conn->query("SELECT COALESCE(SUM(parking_fee), 0) as total FROM vehicles WHERE status = 'checked_out' AND MONTH(check_out_time) = MONTH(CURDATE()) AND YEAR(check_out_time) = YEAR(CURDATE())");
$stats['month_revenue'] = $result->fetch_assoc()['total'];

// 7. Today Revenue
$result = $conn->query("SELECT COALESCE(SUM(parking_fee), 0) as total FROM vehicles WHERE status = 'checked_out' AND DATE(check_out_time) = CURDATE()");
$stats['today_revenue'] = $result->fetch_assoc()['total'];

// 8. Parking Areas
$result = $conn->query("SELECT COUNT(*) as count FROM areas WHERE status = 'active'");
$stats['parking_areas'] = $result->fetch_assoc()['count'];

// Additional stats for other sections
$result = $conn->query("SELECT COUNT(*) as count FROM users WHERE status = 'active'");
$stats['users'] = $result->fetch_assoc()['count'];

$result = $conn->query("SELECT COUNT(*) as count FROM vehicle_types WHERE status = 'active'");
$stats['vehicle_types'] = $result->fetch_assoc()['count'];

// Recent activity - Last 5 checked-in vehicles
$recent_checkins = [];
$result = $conn->query("SELECT v.vehicle_number, vt.type_name, vt.icon_path, a.area_name, v.check_in_time 
                        FROM vehicles v
                        LEFT JOIN vehicle_types vt ON v.vehicle_type_id = vt.id
                        LEFT JOIN areas a ON v.area_id = a.id
                        WHERE v.status = 'parked'
                        ORDER BY v.check_in_time DESC
                        LIMIT 5");
while ($row = $result->fetch_assoc()) {
    $recent_checkins[] = $row;
}

// Recent checkouts - Last 5 checked-out vehicles
$recent_checkouts = [];
$result = $conn->query("SELECT v.vehicle_number, vt.type_name, v.parking_fee, v.check_out_time 
                        FROM vehicles v
                        LEFT JOIN vehicle_types vt ON v.vehicle_type_id = vt.id
                        WHERE v.status = 'checked_out'
                        ORDER BY v.check_out_time DESC
                        LIMIT 5");
while ($row = $result->fetch_assoc()) {
    $recent_checkouts[] = $row;
}

// Vehicle type distribution
$vehicle_distribution = [];
$result = $conn->query("SELECT vt.type_name, vt.icon_path, COUNT(v.id) as count 
                        FROM vehicle_types vt
                        LEFT JOIN vehicles v ON vt.id = v.vehicle_type_id AND v.status = 'parked'
                        WHERE vt.status = 'active'
                        GROUP BY vt.id, vt.type_name, vt.icon_path");
while ($row = $result->fetch_assoc()) {
    $vehicle_distribution[] = $row;
}

// Monthly parking count (last 30 days)
$monthly_parking = [];
$monthly_labels = [];
for ($i = 29; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-$i days"));
    $label = date('M d', strtotime("-$i days")); // Jan 01, Jan 02, etc.
    
    $result = $conn->query("SELECT COUNT(*) as count 
                           FROM vehicles 
                           WHERE DATE(check_in_time) = '$date'");
    $row = $result->fetch_assoc();
    
    $monthly_labels[] = $label;
    $monthly_parking[] = $row['count'];
}

// Monthly revenue (last 30 days)
$monthly_revenue = [];
for ($i = 29; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-$i days"));
    
    $result = $conn->query("SELECT COALESCE(SUM(parking_fee), 0) as total 
                           FROM vehicles 
                           WHERE DATE(check_out_time) = '$date' 
                           AND status = 'checked_out'");
    $row = $result->fetch_assoc();
    
    $monthly_revenue[] = $row['total'];
}

closeDBConnection($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
    <title>Admin Panel - Parking System</title>
    <link rel="stylesheet" href="style.css">
    <?php include 'protection.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
</head>
<body>
    <?php include 'header.php'; ?>
    
    <div class="container">
        <!-- Welcome Header with Time -->
        <div class="dashboard-header">
            <div class="welcome-section">
                <h1 class="gradient-text">Dashboard Overview</h1>
                <p class="dashboard-subtitle">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="12" cy="12" r="10"></circle>
                        <polyline points="12 6 12 12 16 14"></polyline>
                    </svg>
                    <?php echo date('l, F j, Y - h:i A'); ?>
                </p>
            </div>
            <div class="header-actions">
                <a href="../checkin.php" class="btn-gradient">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <line x1="12" y1="5" x2="12" y2="19"></line>
                        <line x1="5" y1="12" x2="19" y2="12"></line>
                    </svg>
                    Check In Vehicle
                </a>
            </div>
        </div>

        <!-- Statistics Cards with Animation -->
        <div class="stats-grid-creative stats-grid-8">
            <!-- 1. Total Parking -->
            <div class="stat-card-creative" data-animate="true">
                <div class="stat-card-header">
                    <div class="stat-icon-creative" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"></path>
                            <line x1="7" y1="7" x2="7.01" y2="7"></line>
                        </svg>
                    </div>
                    <span class="stat-badge-small">All Time</span>
                </div>
                <div class="stat-content">
                    <h2 class="stat-number" data-target="<?php echo $stats['total_parking']; ?>">0</h2>
                    <p class="stat-label">Total Parking</p>
                    <div class="stat-progress">
                        <div class="progress-bar" style="background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);"></div>
                    </div>
                </div>
            </div>

            <!-- 2. Today Parking -->
            <div class="stat-card-creative" data-animate="true">
                <div class="stat-card-header">
                    <div class="stat-icon-creative" style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                            <circle cx="8.5" cy="7" r="4"></circle>
                            <polyline points="17 11 19 13 23 9"></polyline>
                        </svg>
                    </div>
                    <span class="stat-badge-small">Today</span>
                </div>
                <div class="stat-content">
                    <h2 class="stat-number" data-target="<?php echo $stats['today_parking']; ?>">0</h2>
                    <p class="stat-label">Today Parking</p>
                    <div class="stat-progress">
                        <div class="progress-bar" style="background: linear-gradient(90deg, #f093fb 0%, #f5576c 100%);"></div>
                    </div>
                </div>
            </div>

            <!-- 3. Current Parking -->
            <div class="stat-card-creative" data-animate="true">
                <div class="stat-card-header">
                    <div class="stat-icon-creative" style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                            <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                        </svg>
                    </div>
                    <span class="stat-badge-small stat-badge-live">
                        <span class="pulse-dot"></span>
                        Live
                    </span>
                </div>
                <div class="stat-content">
                    <h2 class="stat-number" data-target="<?php echo $stats['current_parking']; ?>">0</h2>
                    <p class="stat-label">Current Parking</p>
                    <div class="stat-progress">
                        <div class="progress-bar" style="background: linear-gradient(90deg, #4facfe 0%, #00f2fe 100%);"></div>
                    </div>
                </div>
            </div>

            <!-- 4. Today Checkout -->
            <div class="stat-card-creative" data-animate="true">
                <div class="stat-card-header">
                    <div class="stat-icon-creative" style="background: linear-gradient(135deg, #fa709a 0%, #fee140 100%);">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polyline points="9 11 12 14 22 4"></polyline>
                            <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path>
                        </svg>
                    </div>
                    <span class="stat-badge-small">Today</span>
                </div>
                <div class="stat-content">
                    <h2 class="stat-number" data-target="<?php echo $stats['today_checkout']; ?>">0</h2>
                    <p class="stat-label">Today Checkout</p>
                    <div class="stat-progress">
                        <div class="progress-bar" style="background: linear-gradient(90deg, #fa709a 0%, #fee140 100%);"></div>
                    </div>
                </div>
            </div>

            <!-- 5. Total Revenue -->
            <div class="stat-card-creative stat-card-featured" data-animate="true">
                <div class="featured-overlay"></div>
                <div class="stat-card-header">
                    <div class="stat-icon-creative" style="background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <line x1="12" y1="1" x2="12" y2="23"></line>
                            <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
                        </svg>
                    </div>
                    <span class="stat-badge-premium">💰 All Time</span>
                </div>
                <div class="stat-content">
                    <h2 class="stat-number stat-number-large">Rs. <?php echo number_format($stats['total_revenue'], 2); ?></h2>
                    <p class="stat-label">Total Revenue</p>
                </div>
            </div>

            <!-- 6. Month Revenue -->
            <div class="stat-card-creative" data-animate="true">
                <div class="stat-card-header">
                    <div class="stat-icon-creative" style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                            <line x1="16" y1="2" x2="16" y2="6"></line>
                            <line x1="8" y1="2" x2="8" y2="6"></line>
                            <line x1="3" y1="10" x2="21" y2="10"></line>
                        </svg>
                    </div>
                    <span class="stat-badge-small">This Month</span>
                </div>
                <div class="stat-content">
                    <h2 class="stat-number stat-number-medium">Rs. <?php echo number_format($stats['month_revenue'], 2); ?></h2>
                    <p class="stat-label">Month Revenue</p>
                    <div class="stat-progress">
                        <div class="progress-bar" style="background: linear-gradient(90deg, #4facfe 0%, #00f2fe 100%);"></div>
                    </div>
                </div>
            </div>

            <!-- 7. Today Revenue -->
            <div class="stat-card-creative" data-animate="true">
                <div class="stat-card-header">
                    <div class="stat-icon-creative" style="background: linear-gradient(135deg, #FF9800 0%, #FF5722 100%);">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <line x1="12" y1="1" x2="12" y2="23"></line>
                            <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
                        </svg>
                    </div>
                    <span class="stat-badge-small">Today</span>
                </div>
                <div class="stat-content">
                    <h2 class="stat-number stat-number-medium">Rs. <?php echo number_format($stats['today_revenue'], 2); ?></h2>
                    <p class="stat-label">Today Revenue</p>
                    <div class="stat-progress">
                        <div class="progress-bar" style="background: linear-gradient(90deg, #FF9800 0%, #FF5722 100%);"></div>
                    </div>
                </div>
            </div>

            <!-- 8. Parking Areas -->
            <div class="stat-card-creative" data-animate="true">
                <div class="stat-card-header">
                    <div class="stat-icon-creative" style="background: linear-gradient(135deg, #a8edea 0%, #fed6e3 100%);">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                            <circle cx="12" cy="10" r="3"></circle>
                        </svg>
                    </div>
                    <span class="stat-badge-small">Active</span>
                </div>
                <div class="stat-content">
                    <h2 class="stat-number" data-target="<?php echo $stats['parking_areas']; ?>">0</h2>
                    <p class="stat-label">Parking Areas</p>
                    <div class="stat-progress">
                        <div class="progress-bar" style="background: linear-gradient(90deg, #a8edea 0%, #fed6e3 100%);"></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Analytics Charts -->
        <div class="charts-section">
            <div class="chart-card">
                <div class="chart-header">
                    <div class="chart-title">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline>
                        </svg>
                        <h3>Monthly Parking Trend</h3>
                    </div>
                    <div class="chart-period">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                            <line x1="16" y1="2" x2="16" y2="6"></line>
                            <line x1="8" y1="2" x2="8" y2="6"></line>
                            <line x1="3" y1="10" x2="21" y2="10"></line>
                        </svg>
                        Last 30 Days
                    </div>
                </div>
                <div class="chart-body">
                    <canvas id="parkingChart"></canvas>
                </div>
                <div class="chart-footer">
                    <div class="chart-stat">
                        <span class="chart-stat-label">Total Check-ins</span>
                        <span class="chart-stat-value"><?php echo array_sum($monthly_parking); ?></span>
                    </div>
                    <div class="chart-stat">
                        <span class="chart-stat-label">Daily Average</span>
                        <span class="chart-stat-value"><?php echo number_format(array_sum($monthly_parking) / 30, 1); ?></span>
                    </div>
                    <div class="chart-stat">
                        <span class="chart-stat-label">Peak Day</span>
                        <span class="chart-stat-value"><?php echo $monthly_labels[array_search(max($monthly_parking), $monthly_parking)]; ?></span>
                    </div>
                </div>
            </div>

            <div class="chart-card">
                <div class="chart-header">
                    <div class="chart-title">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <line x1="12" y1="1" x2="12" y2="23"></line>
                            <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
                        </svg>
                        <h3>Monthly Revenue Trend</h3>
                    </div>
                    <div class="chart-period">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                            <line x1="16" y1="2" x2="16" y2="6"></line>
                            <line x1="8" y1="2" x2="8" y2="6"></line>
                            <line x1="3" y1="10" x2="21" y2="10"></line>
                        </svg>
                        Last 30 Days
                    </div>
                </div>
                <div class="chart-body">
                    <canvas id="revenueChart"></canvas>
                </div>
                <div class="chart-footer">
                    <div class="chart-stat">
                        <span class="chart-stat-label">Total Revenue</span>
                        <span class="chart-stat-value">Rs. <?php echo number_format(array_sum($monthly_revenue), 2); ?></span>
                    </div>
                    <div class="chart-stat">
                        <span class="chart-stat-label">Daily Average</span>
                        <span class="chart-stat-value">Rs. <?php echo number_format(array_sum($monthly_revenue) / 30, 2); ?></span>
                    </div>
                    <div class="chart-stat">
                        <span class="chart-stat-label">Best Day</span>
                        <span class="chart-stat-value"><?php echo $monthly_labels[array_search(max($monthly_revenue), $monthly_revenue)]; ?></span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Two Column Layout -->
        <div class="dashboard-grid">
            <!-- Left Column -->
            <div class="dashboard-left">
                <!-- Vehicle Distribution -->
                <div class="dashboard-card">
                    <div class="card-header">
                        <h3>
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <circle cx="12" cy="12" r="10"></circle>
                                <line x1="12" y1="8" x2="12" y2="16"></line>
                                <line x1="8" y1="12" x2="16" y2="12"></line>
                            </svg>
                            Currently Parked by Type
                        </h3>
                    </div>
                    <div class="card-body">
                        <div class="vehicle-distribution">
                            <?php 
                            $colors = ['#667eea', '#f093fb', '#4facfe', '#fa709a'];
                            $index = 0;
                            foreach ($vehicle_distribution as $dist): 
                                $percentage = $stats['current_parking'] > 0 ? ($dist['count'] / $stats['current_parking']) * 100 : 0;
                            ?>
                            <div class="distribution-item">
                                <div class="distribution-info">
                                    <img src="../<?php echo htmlspecialchars($dist['icon_path']); ?>" 
                                         alt="<?php echo htmlspecialchars($dist['type_name']); ?>" 
                                         class="distribution-icon">
                                    <div class="distribution-details">
                                        <span class="distribution-name"><?php echo htmlspecialchars($dist['type_name']); ?></span>
                                        <span class="distribution-count"><?php echo $dist['count']; ?> vehicles</span>
                                    </div>
                                </div>
                                <div class="distribution-bar">
                                    <div class="bar-fill" style="width: <?php echo $percentage; ?>%; background: <?php echo $colors[$index % 4]; ?>;"></div>
                                </div>
                                <span class="distribution-percentage"><?php echo number_format($percentage, 1); ?>%</span>
                            </div>
                            <?php 
                                $index++;
                            endforeach; 
                            ?>
                        </div>
                    </div>
                </div>

                <!-- Recent Check-ins -->
                <div class="dashboard-card">
                    <div class="card-header">
                        <h3>
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <polyline points="23 6 13.5 15.5 8.5 10.5 1 18"></polyline>
                                <polyline points="23 6 18 6 18 11"></polyline>
                            </svg>
                            Recent Check-ins
                        </h3>
                        <a href="vehicles.php" class="card-link">View All</a>
                    </div>
                    <div class="card-body">
                        <div class="activity-list">
                            <?php if (empty($recent_checkins)): ?>
                                <p class="no-data">No recent check-ins</p>
                            <?php else: ?>
                                <?php foreach ($recent_checkins as $checkin): ?>
                                <div class="activity-item">
                                    <div class="activity-icon" style="background: #e3f2fd;">
                                        <img src="../<?php echo htmlspecialchars($checkin['icon_path']); ?>" 
                                             alt="<?php echo htmlspecialchars($checkin['type_name']); ?>" 
                                             style="width: 24px; height: 24px;">
                                    </div>
                                    <div class="activity-details">
                                        <p class="activity-title"><strong><?php echo htmlspecialchars($checkin['vehicle_number']); ?></strong></p>
                                        <p class="activity-meta">
                                            <?php echo htmlspecialchars($checkin['type_name']); ?> • 
                                            <?php echo htmlspecialchars($checkin['area_name']); ?>
                                        </p>
                                    </div>
                                    <div class="activity-time">
                                        <?php 
                                        $time_diff = time() - strtotime($checkin['check_in_time']);
                                        if ($time_diff < 3600) {
                                            echo floor($time_diff / 60) . 'm ago';
                                        } elseif ($time_diff < 86400) {
                                            echo floor($time_diff / 3600) . 'h ago';
                                        } else {
                                            echo date('M d', strtotime($checkin['check_in_time']));
                                        }
                                        ?>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Right Column -->
            <div class="dashboard-right">
                <!-- Quick Links -->
                <div class="dashboard-card card-compact">
                    <div class="card-header">
                        <h3>
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <polyline points="13 17 18 12 13 7"></polyline>
                                <polyline points="6 17 11 12 6 7"></polyline>
                            </svg>
                            Quick Links
                        </h3>
                    </div>
                    <div class="card-body">
                        <div class="quick-links">
                            <div class="quick-link-item" onclick="window.location.href='vehicles_breakdown.php'">
                                <div class="quick-link-icon" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
                                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                                        <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                                    </svg>
                                </div>
                                <div class="quick-link-details">
                                    <span class="quick-link-label">Total Parking</span>
                                    <span class="quick-link-value"><?php echo $stats['total_parking']; ?></span>
                                </div>
                                <svg class="quick-link-arrow" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <polyline points="9 18 15 12 9 6"></polyline>
                                </svg>
                            </div>

                            <div class="quick-link-item" onclick="window.location.href='areas_breakdown.php'">
                                <div class="quick-link-icon" style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);">
                                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                                        <circle cx="12" cy="10" r="3"></circle>
                                    </svg>
                                </div>
                                <div class="quick-link-details">
                                    <span class="quick-link-label">Total Areas</span>
                                    <span class="quick-link-value"><?php echo $stats['parking_areas']; ?></span>
                                </div>
                                <svg class="quick-link-arrow" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <polyline points="9 18 15 12 9 6"></polyline>
                                </svg>
                            </div>

                            <div class="quick-link-item" onclick="window.location.href='user_breakdown.php'">
                                <div class="quick-link-icon" style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);">
                                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                                        <circle cx="9" cy="7" r="4"></circle>
                                        <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                                        <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                                    </svg>
                                </div>
                                <div class="quick-link-details">
                                    <span class="quick-link-label">Total Users</span>
                                    <span class="quick-link-value"><?php echo $stats['users']; ?></span>
                                </div>
                                <svg class="quick-link-arrow" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <polyline points="9 18 15 12 9 6"></polyline>
                                </svg>
                            </div>

                            <a href="revenue_breakdown.php" class="quick-link-item" style="text-decoration: none; color: inherit;">
                                <div class="quick-link-icon" style="background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);">
                                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <line x1="12" y1="1" x2="12" y2="23"></line>
                                        <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
                                    </svg>
                                </div>
                                <div class="quick-link-details">
                                    <span class="quick-link-label">Total Revenue</span>
                                    <span class="quick-link-value">Rs. <?php echo number_format($stats['total_revenue'], 0); ?></span>
                                </div>
                                <svg class="quick-link-arrow" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <polyline points="9 18 15 12 9 6"></polyline>
                                </svg>
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Recent Checkouts -->
                <div class="dashboard-card">
                    <div class="card-header">
                        <h3>
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <polyline points="9 11 12 14 22 4"></polyline>
                                <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path>
                            </svg>
                            Recent Checkouts
                        </h3>
                        <a href="vehicles.php" class="card-link">View All</a>
                    </div>
                    <div class="card-body">
                        <div class="activity-list">
                            <?php if (empty($recent_checkouts)): ?>
                                <p class="no-data">No recent checkouts</p>
                            <?php else: ?>
                                <?php foreach ($recent_checkouts as $checkout): ?>
                                <div class="activity-item">
                                    <div class="activity-icon" style="background: #f3e5f5;">
                                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#9C27B0" stroke-width="2">
                                            <polyline points="9 11 12 14 22 4"></polyline>
                                            <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path>
                                        </svg>
                                    </div>
                                    <div class="activity-details">
                                        <p class="activity-title"><strong><?php echo htmlspecialchars($checkout['vehicle_number']); ?></strong></p>
                                        <p class="activity-meta">
                                            <?php echo htmlspecialchars($checkout['type_name']); ?> • 
                                            Rs. <?php echo number_format($checkout['parking_fee'], 2); ?>
                                        </p>
                                    </div>
                                    <div class="activity-time">
                                        <?php 
                                        $time_diff = time() - strtotime($checkout['check_out_time']);
                                        if ($time_diff < 3600) {
                                            echo floor($time_diff / 60) . 'm ago';
                                        } elseif ($time_diff < 86400) {
                                            echo floor($time_diff / 3600) . 'h ago';
                                        } else {
                                            echo date('M d', strtotime($checkout['check_out_time']));
                                        }
                                        ?>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <script src="script.js"></script>
    <script>
        // Chart.js Configuration
        Chart.defaults.font.family = '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif';
        Chart.defaults.color = '#6c757d';

        // Monthly Parking Chart
        const parkingCtx = document.getElementById('parkingChart').getContext('2d');
        const parkingChart = new Chart(parkingCtx, {
            type: 'line',
            data: {
                labels: <?php echo json_encode($monthly_labels); ?>,
                datasets: [{
                    label: 'Check-ins',
                    data: <?php echo json_encode($monthly_parking); ?>,
                    backgroundColor: 'rgba(102, 126, 234, 0.1)',
                    borderColor: 'rgba(102, 126, 234, 1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4,
                    pointBackgroundColor: '#fff',
                    pointBorderColor: 'rgba(102, 126, 234, 1)',
                    pointBorderWidth: 2,
                    pointRadius: 3,
                    pointHoverRadius: 6,
                    pointHoverBackgroundColor: 'rgba(102, 126, 234, 1)',
                    pointHoverBorderColor: '#fff',
                    pointHoverBorderWidth: 3
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        padding: 12,
                        titleFont: {
                            size: 14,
                            weight: 'bold'
                        },
                        bodyFont: {
                            size: 13
                        },
                        displayColors: false,
                        callbacks: {
                            label: function(context) {
                                return 'Vehicles: ' + context.parsed.y;
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            precision: 0,
                            font: {
                                size: 12
                            }
                        },
                        grid: {
                            color: 'rgba(0, 0, 0, 0.05)',
                            drawBorder: false
                        }
                    },
                    x: {
                        ticks: {
                            font: {
                                size: 10,
                                weight: '600'
                            },
                            maxRotation: 45,
                            minRotation: 45,
                            autoSkip: true,
                            maxTicksLimit: 15
                        },
                        grid: {
                            display: false,
                            drawBorder: false
                        }
                    }
                },
                interaction: {
                    intersect: false,
                    mode: 'index'
                }
            }
        });

        // Monthly Revenue Chart
        const revenueCtx = document.getElementById('revenueChart').getContext('2d');
        const revenueChart = new Chart(revenueCtx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($monthly_labels); ?>,
                datasets: [{
                    label: 'Revenue',
                    data: <?php echo json_encode($monthly_revenue); ?>,
                    backgroundColor: function(context) {
                        const gradient = context.chart.ctx.createLinearGradient(0, 0, 0, 300);
                        gradient.addColorStop(0, 'rgba(79, 172, 254, 0.8)');
                        gradient.addColorStop(1, 'rgba(0, 242, 254, 0.8)');
                        return gradient;
                    },
                    borderColor: 'rgba(79, 172, 254, 1)',
                    borderWidth: 2,
                    borderRadius: 6,
                    borderSkipped: false
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        padding: 12,
                        titleFont: {
                            size: 14,
                            weight: 'bold'
                        },
                        bodyFont: {
                            size: 13
                        },
                        displayColors: false,
                        callbacks: {
                            label: function(context) {
                                return 'Revenue: Rs. ' + context.parsed.y.toFixed(2);
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            font: {
                                size: 12
                            },
                            callback: function(value) {
                                return 'Rs. ' + value;
                            }
                        },
                        grid: {
                            color: 'rgba(0, 0, 0, 0.05)',
                            drawBorder: false
                        }
                    },
                    x: {
                        ticks: {
                            font: {
                                size: 10,
                                weight: '600'
                            },
                            maxRotation: 45,
                            minRotation: 45,
                            autoSkip: true,
                            maxTicksLimit: 15
                        },
                        grid: {
                            display: false,
                            drawBorder: false
                        }
                    }
                },
                interaction: {
                    intersect: false,
                    mode: 'index'
                }
            }
        });

        // Animate charts on scroll
        const chartObserver = new IntersectionObserver(function(entries) {
            entries.forEach(function(entry) {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        }, {
            threshold: 0.1
        });

        document.querySelectorAll('.chart-card').forEach(function(card) {
            card.style.opacity = '0';
            card.style.transform = 'translateY(30px)';
            card.style.transition = 'all 0.6s ease';
            chartObserver.observe(card);
        });
    </script>
</body>
</html>


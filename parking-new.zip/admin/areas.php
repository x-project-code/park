<?php
session_start();
require_once '../config.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id']) || !isset($_SESSION['is_admin'])) {
    header('Location: login.php');
    exit();
}

$conn = getDBConnection();

// Handle CRUD operations
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'create') {
        $area_code = $conn->real_escape_string($_POST['area_code']);
        $area_name = $conn->real_escape_string($_POST['area_name']);
        $capacity = intval($_POST['capacity']);
        $status = $conn->real_escape_string($_POST['status']);
        
        $sql = "INSERT INTO areas (area_code, area_name, capacity, status) VALUES ('$area_code', '$area_name', $capacity, '$status')";
        
        if ($conn->query($sql)) {
            $_SESSION['success_message'] = "Area created successfully!";
        } else {
            $_SESSION['error_message'] = "Error: " . $conn->error;
        }
        header('Location: areas.php');
        exit();
    }
    
    if ($action === 'update') {
        $id = intval($_POST['id']);
        $area_code = $conn->real_escape_string($_POST['area_code']);
        $area_name = $conn->real_escape_string($_POST['area_name']);
        $capacity = intval($_POST['capacity']);
        $status = $conn->real_escape_string($_POST['status']);
        
        $sql = "UPDATE areas SET area_code='$area_code', area_name='$area_name', capacity=$capacity, status='$status' WHERE id=$id";
        
        if ($conn->query($sql)) {
            $_SESSION['success_message'] = "Area updated successfully!";
        } else {
            $_SESSION['error_message'] = "Error: " . $conn->error;
        }
        header('Location: areas.php');
        exit();
    }
    
    if ($action === 'delete') {
        $id = intval($_POST['id']);
        $sql = "DELETE FROM areas WHERE id=$id";
        
        if ($conn->query($sql)) {
            $_SESSION['success_message'] = "Area deleted successfully!";
        } else {
            $_SESSION['error_message'] = "Error: " . $conn->error;
        }
        header('Location: areas.php');
        exit();
    }
}

// Fetch all areas
$result = $conn->query("SELECT * FROM areas ORDER BY id DESC");
$areas = [];
while ($row = $result->fetch_assoc()) {
    $areas[] = $row;
}

closeDBConnection($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
    <title>Manage Areas - Admin Panel</title>
    <link rel="stylesheet" href="style.css">
    <?php include 'protection.php'; ?>
</head>
<body>
    <?php include 'header.php'; ?>
    
    <div class="container">
        <div class="page-header">
            <h1>Manage Parking Areas</h1>
            <button class="btn btn-primary" onclick="openModal('createModal')">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <line x1="12" y1="5" x2="12" y2="19"></line>
                    <line x1="5" y1="12" x2="19" y2="12"></line>
                </svg>
                Add New Area
            </button>
        </div>

        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success">
                <?php echo $_SESSION['success_message']; unset($_SESSION['success_message']); ?>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="alert alert-error">
                <?php echo $_SESSION['error_message']; unset($_SESSION['error_message']); ?>
            </div>
        <?php endif; ?>

        <div class="table-container">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Area Code</th>
                        <th>Area Name</th>
                        <th>Capacity</th>
                        <th>Status</th>
                        <th>Created At</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($areas as $area): ?>
                    <tr>
                        <td data-label="ID"><?php echo $area['id']; ?></td>
                        <td data-label="Area Code"><strong><?php echo htmlspecialchars($area['area_code']); ?></strong></td>
                        <td data-label="Area Name"><?php echo htmlspecialchars($area['area_name']); ?></td>
                        <td data-label="Capacity"><?php echo number_format($area['capacity']); ?></td>
                        <td data-label="Status">
                            <span class="badge badge-<?php echo $area['status']; ?>">
                                <?php echo ucfirst($area['status']); ?>
                            </span>
                        </td>
                        <td data-label="Created At"><?php echo date('Y-m-d H:i', strtotime($area['created_at'])); ?></td>
                        <td data-label="Actions">
                            <div class="action-buttons">
                                <button class="btn-icon btn-edit" onclick='editArea(<?php echo json_encode($area); ?>)' title="Edit">
                                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                        <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                                    </svg>
                                </button>
                                <button class="btn-icon btn-delete" onclick="deleteArea(<?php echo $area['id']; ?>, '<?php echo htmlspecialchars($area['area_name']); ?>')" title="Delete">
                                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <polyline points="3 6 5 6 21 6"></polyline>
                                        <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                                    </svg>
                                </button>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Create Modal -->
    <div id="createModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Add New Area</h2>
                <button class="close-btn" onclick="closeModal('createModal')">&times;</button>
            </div>
            <form method="POST" class="modal-form">
                <input type="hidden" name="action" value="create">
                
                <div class="form-group">
                    <label>Area Code *</label>
                    <input type="text" name="area_code" required placeholder="e.g., AREA01">
                </div>
                
                <div class="form-group">
                    <label>Area Name *</label>
                    <input type="text" name="area_name" required placeholder="e.g., AREA 01">
                </div>
                
                <div class="form-group">
                    <label>Capacity *</label>
                    <input type="number" name="capacity" required min="1" placeholder="e.g., 50000">
                </div>
                
                <div class="form-group">
                    <label>Status *</label>
                    <select name="status" required>
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                        <option value="full">Full</option>
                    </select>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="closeModal('createModal')">Cancel</button>
                    <button type="submit" class="btn btn-primary">Create Area</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Edit Modal -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Edit Area</h2>
                <button class="close-btn" onclick="closeModal('editModal')">&times;</button>
            </div>
            <form method="POST" class="modal-form">
                <input type="hidden" name="action" value="update">
                <input type="hidden" name="id" id="edit_id">
                
                <div class="form-group">
                    <label>Area Code *</label>
                    <input type="text" name="area_code" id="edit_area_code" required>
                </div>
                
                <div class="form-group">
                    <label>Area Name *</label>
                    <input type="text" name="area_name" id="edit_area_name" required>
                </div>
                
                <div class="form-group">
                    <label>Capacity *</label>
                    <input type="number" name="capacity" id="edit_capacity" required min="1">
                </div>
                
                <div class="form-group">
                    <label>Status *</label>
                    <select name="status" id="edit_status" required>
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                        <option value="full">Full</option>
                    </select>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="closeModal('editModal')">Cancel</button>
                    <button type="submit" class="btn btn-primary">Update Area</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Delete Modal -->
    <div id="deleteModal" class="modal">
        <div class="modal-content modal-small">
            <div class="modal-header">
                <h2>Confirm Delete</h2>
                <button class="close-btn" onclick="closeModal('deleteModal')">&times;</button>
            </div>
            <form method="POST">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" id="delete_id">
                
                <p class="delete-message">Are you sure you want to delete area <strong id="delete_name"></strong>?</p>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="closeModal('deleteModal')">Cancel</button>
                    <button type="submit" class="btn btn-danger">Delete</button>
                </div>
            </form>
        </div>
    </div>

    <script src="script.js"></script>
    <script>
        function editArea(area) {
            document.getElementById('edit_id').value = area.id;
            document.getElementById('edit_area_code').value = area.area_code;
            document.getElementById('edit_area_name').value = area.area_name;
            document.getElementById('edit_capacity').value = area.capacity;
            document.getElementById('edit_status').value = area.status;
            openModal('editModal');
        }

        function deleteArea(id, name) {
            document.getElementById('delete_id').value = id;
            document.getElementById('delete_name').textContent = name;
            openModal('deleteModal');
        }
    </script>
</body>
</html>


<?php
session_start();
require_once '../config.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id']) || !isset($_SESSION['is_admin'])) {
    header('Location: login.php');
    exit();
}

$conn = getDBConnection();

// Handle CRUD operations
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'create') {
        $type_code = $conn->real_escape_string($_POST['type_code']);
        $type_name = $conn->real_escape_string($_POST['type_name']);
        $rate_per_hour = floatval($_POST['rate_per_hour']);
        $next_hour = floatval($_POST['next_hour']);
        $icon_path = $conn->real_escape_string($_POST['icon_path']);
        $status = $conn->real_escape_string($_POST['status']);
        
        $sql = "INSERT INTO vehicle_types (type_code, type_name, rate_per_hour, next_hour, icon_path, status) 
                VALUES ('$type_code', '$type_name', $rate_per_hour, $next_hour, '$icon_path', '$status')";
        
        if ($conn->query($sql)) {
            $_SESSION['success_message'] = "Vehicle type created successfully!";
        } else {
            $_SESSION['error_message'] = "Error: " . $conn->error;
        }
        header('Location: vehicle_types.php');
        exit();
    }
    
    if ($action === 'update') {
        $id = intval($_POST['id']);
        $type_code = $conn->real_escape_string($_POST['type_code']);
        $type_name = $conn->real_escape_string($_POST['type_name']);
        $rate_per_hour = floatval($_POST['rate_per_hour']);
        $next_hour = floatval($_POST['next_hour']);
        $icon_path = $conn->real_escape_string($_POST['icon_path']);
        $status = $conn->real_escape_string($_POST['status']);
        
        $sql = "UPDATE vehicle_types SET type_code='$type_code', type_name='$type_name', 
                rate_per_hour=$rate_per_hour, next_hour=$next_hour, icon_path='$icon_path', status='$status' 
                WHERE id=$id";
        
        if ($conn->query($sql)) {
            $_SESSION['success_message'] = "Vehicle type updated successfully!";
        } else {
            $_SESSION['error_message'] = "Error: " . $conn->error;
        }
        header('Location: vehicle_types.php');
        exit();
    }
    
    if ($action === 'delete') {
        $id = intval($_POST['id']);
        $sql = "DELETE FROM vehicle_types WHERE id=$id";
        
        if ($conn->query($sql)) {
            $_SESSION['success_message'] = "Vehicle type deleted successfully!";
        } else {
            $_SESSION['error_message'] = "Error: " . $conn->error;
        }
        header('Location: vehicle_types.php');
        exit();
    }
}

// Fetch all vehicle types
$result = $conn->query("SELECT * FROM vehicle_types ORDER BY id DESC");
$vehicle_types = [];
while ($row = $result->fetch_assoc()) {
    $vehicle_types[] = $row;
}

closeDBConnection($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
    <title>Manage Vehicle Types - Admin Panel</title>
    <link rel="stylesheet" href="style.css">
    <?php include 'protection.php'; ?>
</head>
<body>
    <?php include 'header.php'; ?>
    
    <div class="container">
        <div class="page-header">
            <h1>Manage Vehicle Types</h1>
            <button class="btn btn-primary" onclick="openModal('createModal')">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <line x1="12" y1="5" x2="12" y2="19"></line>
                    <line x1="5" y1="12" x2="19" y2="12"></line>
                </svg>
                Add New Type
            </button>
        </div>

        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success">
                <?php echo $_SESSION['success_message']; unset($_SESSION['success_message']); ?>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="alert alert-error">
                <?php echo $_SESSION['error_message']; unset($_SESSION['error_message']); ?>
            </div>
        <?php endif; ?>

        <div class="table-container">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Icon</th>
                        <th>Type Code</th>
                        <th>Type Name</th>
                        <th>Rate/Hour (Rs.)</th>
                        <th>Next Hour (Rs.)</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($vehicle_types as $type): ?>
                    <tr>
                        <td data-label="ID"><?php echo $type['id']; ?></td>
                        <td data-label="Icon">
                            <img src="../<?php echo htmlspecialchars($type['icon_path']); ?>" 
                                 alt="<?php echo htmlspecialchars($type['type_name']); ?>" 
                                 class="vehicle-icon">
                        </td>
                        <td data-label="Type Code"><strong><?php echo htmlspecialchars($type['type_code']); ?></strong></td>
                        <td data-label="Type Name"><?php echo htmlspecialchars($type['type_name']); ?></td>
                        <td data-label="Rate/Hour">Rs. <?php echo number_format($type['rate_per_hour'], 2); ?></td>
                        <td data-label="Next Hour">Rs. <?php echo number_format($type['next_hour'], 2); ?></td>
                        <td data-label="Status">
                            <span class="badge badge-<?php echo $type['status']; ?>">
                                <?php echo ucfirst($type['status']); ?>
                            </span>
                        </td>
                        <td data-label="Actions">
                            <div class="action-buttons">
                                <button class="btn-icon btn-edit" onclick='editType(<?php echo json_encode($type); ?>)' title="Edit">
                                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                        <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                                    </svg>
                                </button>
                                <button class="btn-icon btn-delete" onclick="deleteType(<?php echo $type['id']; ?>, '<?php echo htmlspecialchars($type['type_name']); ?>')" title="Delete">
                                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <polyline points="3 6 5 6 21 6"></polyline>
                                        <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                                    </svg>
                                </button>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Create Modal -->
    <div id="createModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Add New Vehicle Type</h2>
                <button class="close-btn" onclick="closeModal('createModal')">&times;</button>
            </div>
            <form method="POST" class="modal-form">
                <input type="hidden" name="action" value="create">
                
                <div class="form-group">
                    <label>Type Code *</label>
                    <input type="text" name="type_code" required placeholder="e.g., car">
                </div>
                
                <div class="form-group">
                    <label>Type Name *</label>
                    <input type="text" name="type_name" required placeholder="e.g., Car">
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Rate Per Hour (Rs.) *</label>
                        <input type="number" step="0.01" name="rate_per_hour" required min="0" placeholder="50.00">
                    </div>
                    
                    <div class="form-group">
                        <label>Next Hour Rate (Rs.) *</label>
                        <input type="number" step="0.01" name="next_hour" required min="0" placeholder="30.00">
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Icon Path *</label>
                    <input type="text" name="icon_path" required placeholder="icon/car.png">
                    <small>Available icons: icon/car.png, icon/racing-bike.png, icon/tuk-tuk.png, icon/transport.png</small>
                </div>
                
                <div class="form-group">
                    <label>Status *</label>
                    <select name="status" required>
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                    </select>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="closeModal('createModal')">Cancel</button>
                    <button type="submit" class="btn btn-primary">Create Type</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Edit Modal -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Edit Vehicle Type</h2>
                <button class="close-btn" onclick="closeModal('editModal')">&times;</button>
            </div>
            <form method="POST" class="modal-form">
                <input type="hidden" name="action" value="update">
                <input type="hidden" name="id" id="edit_id">
                
                <div class="form-group">
                    <label>Type Code *</label>
                    <input type="text" name="type_code" id="edit_type_code" required>
                </div>
                
                <div class="form-group">
                    <label>Type Name *</label>
                    <input type="text" name="type_name" id="edit_type_name" required>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Rate Per Hour (Rs.) *</label>
                        <input type="number" step="0.01" name="rate_per_hour" id="edit_rate_per_hour" required min="0">
                    </div>
                    
                    <div class="form-group">
                        <label>Next Hour Rate (Rs.) *</label>
                        <input type="number" step="0.01" name="next_hour" id="edit_next_hour" required min="0">
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Icon Path *</label>
                    <input type="text" name="icon_path" id="edit_icon_path" required>
                    <small>Available icons: icon/car.png, icon/racing-bike.png, icon/tuk-tuk.png, icon/transport.png</small>
                </div>
                
                <div class="form-group">
                    <label>Status *</label>
                    <select name="status" id="edit_status" required>
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                    </select>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="closeModal('editModal')">Cancel</button>
                    <button type="submit" class="btn btn-primary">Update Type</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Delete Modal -->
    <div id="deleteModal" class="modal">
        <div class="modal-content modal-small">
            <div class="modal-header">
                <h2>Confirm Delete</h2>
                <button class="close-btn" onclick="closeModal('deleteModal')">&times;</button>
            </div>
            <form method="POST">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" id="delete_id">
                
                <p class="delete-message">Are you sure you want to delete vehicle type <strong id="delete_name"></strong>?</p>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="closeModal('deleteModal')">Cancel</button>
                    <button type="submit" class="btn btn-danger">Delete</button>
                </div>
            </form>
        </div>
    </div>

    <script src="script.js"></script>
    <script>
        function editType(type) {
            document.getElementById('edit_id').value = type.id;
            document.getElementById('edit_type_code').value = type.type_code;
            document.getElementById('edit_type_name').value = type.type_name;
            document.getElementById('edit_rate_per_hour').value = type.rate_per_hour;
            document.getElementById('edit_next_hour').value = type.next_hour;
            document.getElementById('edit_icon_path').value = type.icon_path;
            document.getElementById('edit_status').value = type.status;
            openModal('editModal');
        }

        function deleteType(id, name) {
            document.getElementById('delete_id').value = id;
            document.getElementById('delete_name').textContent = name;
            openModal('deleteModal');
        }
    </script>
</body>
</html>


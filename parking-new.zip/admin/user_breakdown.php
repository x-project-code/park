<?php
session_start();
require_once '../config.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id']) || !isset($_SESSION['is_admin'])) {
    header('Location: login.php');
    exit();
}

$conn = getDBConnection();

// Get individual user statistics with earnings and parking details
$user_stats = [];
$total_users = 0;

$result = $conn->query("SELECT 
                        u.id,
                        u.username,
                        u.status,
                        COUNT(v.id) as total_vehicles,
                        SUM(CASE WHEN v.status = 'parked' THEN 1 ELSE 0 END) as currently_parked,
                        SUM(CASE WHEN v.status = 'checked_out' THEN 1 ELSE 0 END) as checked_out,
                        SUM(CASE WHEN v.status = 'checked_out' AND DATE(v.check_out_time) = CURDATE() THEN 1 ELSE 0 END) as today_checkout,
                        COALESCE(SUM(CASE WHEN v.status = 'checked_out' THEN v.parking_fee ELSE 0 END), 0) as total_revenue,
                        COALESCE(SUM(CASE WHEN v.status = 'checked_out' AND DATE(v.check_out_time) = CURDATE() THEN v.parking_fee ELSE 0 END), 0) as today_revenue
                        FROM users u
                        LEFT JOIN vehicles v ON u.id = v.user_id
                        GROUP BY u.id, u.username, u.status
                        ORDER BY total_revenue DESC");

if ($result) {
    while ($row = $result->fetch_assoc()) {
        // Get vehicle list for this user
        $user_id = $row['id'];
        $vehicles_result = $conn->query("SELECT v.id, v.vehicle_number, v.status, v.check_in_time, v.check_out_time, v.parking_fee,
                                         vt.type_name, vt.icon_path,
                                         a.area_name
                                         FROM vehicles v
                                         LEFT JOIN vehicle_types vt ON v.vehicle_type_id = vt.id
                                         LEFT JOIN areas a ON v.area_id = a.id
                                         WHERE v.user_id = $user_id
                                         ORDER BY v.check_in_time DESC");
        
        $row['vehicles'] = [];
        if ($vehicles_result) {
            while ($vehicle = $vehicles_result->fetch_assoc()) {
                $row['vehicles'][] = $vehicle;
            }
        }
        
        $user_stats[] = $row;
        $total_users++;
    }
}

// Get overall statistics
$result = $conn->query("SELECT COUNT(*) as total FROM users");
if ($result) {
    $overall_stats['total'] = $result->fetch_assoc()['total'];
} else {
    $overall_stats['total'] = 0;
}

$result = $conn->query("SELECT COUNT(*) as active FROM users WHERE status = 'active'");
if ($result) {
    $overall_stats['active'] = $result->fetch_assoc()['active'];
} else {
    $overall_stats['active'] = 0;
}

$result = $conn->query("SELECT COUNT(*) as inactive FROM users WHERE status = 'inactive'");
if ($result) {
    $overall_stats['inactive'] = $result->fetch_assoc()['inactive'];
} else {
    $overall_stats['inactive'] = 0;
}

// Since there's no created_at column, set today to 0
$overall_stats['today'] = 0;

closeDBConnection($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
    <title>Users Breakdown - Admin Panel</title>
    <link rel="stylesheet" href="style.css">
    <?php include 'protection.php'; ?>
</head>
<body>
    <?php include 'header.php'; ?>
    
    <div class="container">
        <div class="page-header">
            <div>
                <h1>
                    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="vertical-align: middle; margin-right: 10px;">
                        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                        <circle cx="9" cy="7" r="4"></circle>
                        <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                        <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                    </svg>
                    Users Breakdown
                </h1>
                <p style="margin-top: 8px; color: #6c757d;">Complete statistics by user role</p>
            </div>
            <a href="index.php" class="btn btn-secondary">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <line x1="19" y1="12" x2="5" y2="12"></line>
                    <polyline points="12 19 5 12 12 5"></polyline>
                </svg>
                Back to Dashboard
            </a>
        </div>

        <!-- Overall Statistics -->
        <div class="stats-grid-creative">
            <div class="stat-card-creative">
                <div class="stat-card-header">
                    <div class="stat-icon-creative" style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                            <circle cx="9" cy="7" r="4"></circle>
                            <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                            <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                        </svg>
                    </div>
                    <span class="stat-badge-small">All Time</span>
                </div>
                <div class="stat-content">
                    <h2 class="stat-number"><?php echo number_format($overall_stats['total']); ?></h2>
                    <p class="stat-label">Total Users</p>
                    <div class="stat-progress">
                        <div class="progress-bar" style="background: linear-gradient(90deg, #4facfe 0%, #00f2fe 100%); width: 100%;"></div>
                    </div>
                </div>
            </div>

            <div class="stat-card-creative">
                <div class="stat-card-header">
                    <div class="stat-icon-creative" style="background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                            <polyline points="22 4 12 14.01 9 11.01"></polyline>
                        </svg>
                    </div>
                    <span class="stat-badge-small stat-badge-live">
                        Active
                    </span>
                </div>
                <div class="stat-content">
                    <h2 class="stat-number"><?php echo number_format($overall_stats['active']); ?></h2>
                    <p class="stat-label">Active Users</p>
                    <div class="stat-progress">
                        <div class="progress-bar" style="background: linear-gradient(90deg, #43e97b 0%, #38f9d7 100%); width: 100%;"></div>
                    </div>
                </div>
            </div>

            <div class="stat-card-creative">
                <div class="stat-card-header">
                    <div class="stat-icon-creative" style="background: linear-gradient(135deg, #fa709a 0%, #fee140 100%);">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="12" cy="12" r="10"></circle>
                            <line x1="15" y1="9" x2="9" y2="15"></line>
                            <line x1="9" y1="9" x2="15" y2="15"></line>
                        </svg>
                    </div>
                    <span class="stat-badge-small">Inactive</span>
                </div>
                <div class="stat-content">
                    <h2 class="stat-number"><?php echo number_format($overall_stats['inactive']); ?></h2>
                    <p class="stat-label">Inactive Users</p>
                    <div class="stat-progress">
                        <div class="progress-bar" style="background: linear-gradient(90deg, #fa709a 0%, #fee140 100%); width: 100%;"></div>
                    </div>
                </div>
            </div>

            <div class="stat-card-creative">
                <div class="stat-card-header">
                    <div class="stat-icon-creative" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                            <circle cx="9" cy="7" r="4"></circle>
                            <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                            <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                        </svg>
                    </div>
                    <span class="stat-badge-small">Accounts</span>
                </div>
                <div class="stat-content">
                    <h2 class="stat-number"><?php echo number_format($overall_stats['total']); ?></h2>
                    <p class="stat-label">User Accounts</p>
                    <div class="stat-progress">
                        <div class="progress-bar" style="background: linear-gradient(90deg, #667eea 0%, #764ba2 100%); width: 100%;"></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Individual User Details -->
        <div class="dashboard-card" style="margin-top: 40px;">
            <div class="card-header">
                <h3>
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="12" cy="12" r="10"></circle>
                        <line x1="12" y1="8" x2="12" y2="16"></line>
                        <line x1="8" y1="12" x2="16" y2="12"></line>
                    </svg>
                    Individual User Performance
                </h3>
            </div>
            <div class="card-body">
                <div class="vehicle-type-breakdown">
                    <?php 
                    $status_icons = [
                        'active' => '<svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#000000" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>',
                        'inactive' => '<svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#000000" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>'
                    ];
                    
                    $index = 0;
                    foreach ($user_stats as $stat): 
                        $total_revenue_all = array_sum(array_column($user_stats, 'total_revenue'));
                        $percentage = $total_revenue_all > 0 ? ($stat['total_revenue'] / $total_revenue_all) * 100 : 0;
                        $status_name = ucfirst($stat['status']);
                        $icon = isset($status_icons[$stat['status']]) ? $status_icons[$stat['status']] : $status_icons['active'];
                        
                        // Status badge color
                        $status_badge_color = $stat['status'] == 'active' ? '#43e97b' : '#f44336';
                    ?>
                    <div class="type-breakdown-item" style="background: linear-gradient(135deg, #f5f6fa 0%, #f5f6fa 100%);">
                        <div class="type-breakdown-header">
                            <div class="type-breakdown-info">
                                <div class="type-breakdown-icon-wrapper">
                                    <?php echo $icon; ?>
                                </div>
                                <div class="type-breakdown-title">
                                    <h4 style="color: #ff9800;">
                                        <?php echo htmlspecialchars($stat['username']); ?>
                                        <span style="display: inline-block; background: <?php echo $status_badge_color; ?>; color: white; padding: 2px 8px; border-radius: 12px; font-size: 11px; margin-left: 8px; font-weight: 600;">
                                            <?php echo $status_name; ?>
                                        </span>
                                    </h4>
                                    <span class="type-breakdown-count">Rs. <?php echo number_format($stat['total_revenue'], 2); ?> Total Earned</span>
                                </div>
                            </div>
                            <div class="type-breakdown-percentage" style="color: #ff9800;">
                                <?php echo number_format($percentage, 1); ?>%
                            </div>
                        </div>
                        
                        <div class="type-breakdown-bar">
                            <div class="bar-fill" style="width: <?php echo $percentage; ?>%; background: #ff9800;"></div>
                        </div>

                        <div class="type-breakdown-details">
                            <div class="detail-row">
                                <div class="detail-item">
                                    <div class="detail-icon" style="background: #667eea;">
                                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"></path>
                                            <line x1="7" y1="7" x2="7.01" y2="7"></line>
                                        </svg>
                                    </div>
                                    <div class="detail-content">
                                        <span class="detail-label">Total Vehicles</span>
                                        <span class="detail-value"><?php echo number_format($stat['total_vehicles']); ?></span>
                                    </div>
                                </div>
                                <div class="detail-item">
                                    <div class="detail-icon" style="background: #f093fb;">
                                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                                            <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                                        </svg>
                                    </div>
                                    <div class="detail-content">
                                        <span class="detail-label">Currently Parked</span>
                                        <span class="detail-value"><?php echo number_format($stat['currently_parked']); ?></span>
                                    </div>
                                </div>
                            </div>

                            <div class="detail-row">
                                <div class="detail-item">
                                    <div class="detail-icon" style="background: #43e97b;">
                                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <polyline points="9 11 12 14 22 4"></polyline>
                                            <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path>
                                        </svg>
                                    </div>
                                    <div class="detail-content">
                                        <span class="detail-label">Checked Out</span>
                                        <span class="detail-value"><?php echo number_format($stat['checked_out']); ?></span>
                                    </div>
                                </div>
                                <div class="detail-item">
                                    <div class="detail-icon" style="background: #00BCD4;">
                                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <polyline points="9 11 12 14 22 4"></polyline>
                                            <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path>
                                        </svg>
                                    </div>
                                    <div class="detail-content">
                                        <span class="detail-label">Today Checkout</span>
                                        <span class="detail-value"><?php echo number_format($stat['today_checkout']); ?></span>
                                    </div>
                                </div>
                            </div>

                            <div class="detail-row">
                                <div class="detail-item detail-item-revenue">
                                    <div class="detail-icon detail-icon-revenue">
                                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                                            <line x1="12" y1="1" x2="12" y2="23"></line>
                                            <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
                                        </svg>
                                    </div>
                                    <div class="detail-content">
                                        <span class="detail-label">Total Revenue</span>
                                        <span class="detail-value detail-value-large">Rs. <?php echo number_format($stat['total_revenue'], 2); ?></span>
                                    </div>
                                </div>
                                <div class="detail-item detail-item-revenue">
                                    <div class="detail-icon detail-icon-revenue">
                                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                                            <line x1="12" y1="1" x2="12" y2="23"></line>
                                            <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
                                        </svg>
                                    </div>
                                    <div class="detail-content">
                                        <span class="detail-label">Today Revenue</span>
                                        <span class="detail-value detail-value-large">Rs. <?php echo number_format($stat['today_revenue'], 2); ?></span>
                                    </div>
                                </div>
                            </div>

                            <!-- Vehicle List Section -->
                            <?php if (count($stat['vehicles']) > 0): ?>
                            <div class="vehicle-list-section" style="margin-top: 20px; border-top: 2px solid #e0e0e0; padding-top: 20px;">
                                <div class="vehicle-list-header" style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 15px;">
                                    <!-- <h5 style="margin: 0; color: #2c3e50; font-size: 16px; font-weight: 600; cursor: pointer;" onclick="toggleVehicleList(<?php echo $stat['id']; ?>)">
                                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="vertical-align: middle; margin-right: 8px;">
                                            <rect x="1" y="3" width="15" height="13"></rect>
                                            <polygon points="16 8 20 8 23 11 23 16 16 16 16 8"></polygon>
                                            <circle cx="5.5" cy="18.5" r="2.5"></circle>
                                            <circle cx="18.5" cy="18.5" r="2.5"></circle>
                                        </svg>
                                        Vehicle List (<?php echo count($stat['vehicles']); ?>)
                                    </h5> -->
                                    <div style="display: flex; gap: 12px; align-items: center;">
                                        <a href="vehicles_management.php?user_id=<?php echo $stat['id']; ?>" style="text-decoration: none; color: white; font-weight: 600; font-size: 12px; padding: 8px 16px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 8px; transition: all 0.3s; display: inline-flex; align-items: center; gap: 6px; box-shadow: 0 2px 8px rgba(102, 126, 234, 0.3);" onmouseover="this.style.transform='translateY(-2px)'; this.style.boxShadow='0 4px 12px rgba(102, 126, 234, 0.4)';" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 2px 8px rgba(102, 126, 234, 0.3)';">
                                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                                            </svg>
                                            Manage <?php echo count($stat['vehicles']); ?> Vehicles 
                                        </a>
                                    </div>
                                </div>
                                
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php 
                        $index++;
                    endforeach; 
                    ?>
                </div>
            </div>
        </div>
    </div>

    <script src="script.js"></script>
    <script>
    function toggleVehicleList(userId) {
        const content = document.getElementById('vehicle-list-' + userId);
        const arrow = document.getElementById('arrow-' + userId);
        
        if (content.style.display === 'none') {
            content.style.display = 'block';
            arrow.style.transform = 'rotate(180deg)';
        } else {
            content.style.display = 'none';
            arrow.style.transform = 'rotate(0deg)';
        }
    }
    </script>
</body>
</html>


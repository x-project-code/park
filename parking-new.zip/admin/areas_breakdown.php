<?php
session_start();
require_once '../config.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id']) || !isset($_SESSION['is_admin'])) {
    header('Location: login.php');
    exit();
}

$conn = getDBConnection();

// Get area statistics
$area_stats = [];
$total_vehicles = 0;
$total_revenue = 0;

$result = $conn->query("SELECT a.id, a.area_name, a.area_code, a.capacity, a.status,
                        COUNT(v.id) as total_count,
                        SUM(CASE WHEN v.status = 'parked' THEN 1 ELSE 0 END) as currently_parked,
                        SUM(CASE WHEN DATE(v.check_in_time) = CURDATE() THEN 1 ELSE 0 END) as today_parked,
                        SUM(CASE WHEN v.status = 'checked_out' AND DATE(v.check_out_time) = CURDATE() THEN 1 ELSE 0 END) as today_checkout,
                        SUM(CASE WHEN v.status = 'checked_out' THEN 1 ELSE 0 END) as checked_out,
                        COALESCE(SUM(CASE WHEN v.status = 'checked_out' THEN v.parking_fee ELSE 0 END), 0) as total_revenue,
                        COALESCE(SUM(CASE WHEN v.status = 'checked_out' AND DATE(v.check_out_time) = CURDATE() THEN v.parking_fee ELSE 0 END), 0) as today_revenue
                        FROM areas a
                        LEFT JOIN vehicles v ON a.id = v.area_id
                        WHERE a.status = 'active'
                        GROUP BY a.id, a.area_name, a.area_code, a.capacity, a.status
                        ORDER BY total_count DESC");

while ($row = $result->fetch_assoc()) {
    $area_stats[] = $row;
    $total_vehicles += $row['total_count'];
    $total_revenue += $row['total_revenue'];
}

// Get overall statistics
$result = $conn->query("SELECT COUNT(*) as total FROM vehicles");
$overall_stats['total'] = $result->fetch_assoc()['total'];

$result = $conn->query("SELECT COUNT(*) as parked FROM vehicles WHERE status = 'parked'");
$overall_stats['parked'] = $result->fetch_assoc()['parked'];

$result = $conn->query("SELECT COUNT(*) as checked_out FROM vehicles WHERE status = 'checked_out'");
$overall_stats['checked_out'] = $result->fetch_assoc()['checked_out'];

$result = $conn->query("SELECT COALESCE(SUM(parking_fee), 0) as revenue FROM vehicles WHERE status = 'checked_out'");
$overall_stats['revenue'] = $result->fetch_assoc()['revenue'];

// Get total active areas
$result = $conn->query("SELECT COUNT(*) as count FROM areas WHERE status = 'active'");
$overall_stats['areas'] = $result->fetch_assoc()['count'];

closeDBConnection($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
    <title>Areas Breakdown - Admin Panel</title>
    <link rel="stylesheet" href="style.css">
    <?php include 'protection.php'; ?>
</head>
<body>
    <?php include 'header.php'; ?>
    
    <div class="container">
        <div class="page-header">
            <div>
                <h1>
                    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="vertical-align: middle; margin-right: 10px;">
                        <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                        <circle cx="12" cy="10" r="3"></circle>
                    </svg>
                    Parking Areas Breakdown
                </h1>
                <p style="margin-top: 8px; color: #6c757d;">Complete statistics by parking area</p>
            </div>
            <a href="index.php" class="btn btn-secondary">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <line x1="19" y1="12" x2="5" y2="12"></line>
                    <polyline points="12 19 5 12 12 5"></polyline>
                </svg>
                Back to Dashboard
            </a>
        </div>

        <!-- Overall Statistics -->
        <div class="stats-grid-creative">
            <div class="stat-card-creative">
                <div class="stat-card-header">
                    <div class="stat-icon-creative" style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                            <circle cx="12" cy="10" r="3"></circle>
                        </svg>
                    </div>
                    <span class="stat-badge-small">Active</span>
                </div>
                <div class="stat-content">
                    <h2 class="stat-number"><?php echo number_format($overall_stats['areas']); ?></h2>
                    <p class="stat-label">Total Areas</p>
                    <div class="stat-progress">
                        <div class="progress-bar" style="background: linear-gradient(90deg, #4facfe 0%, #00f2fe 100%); width: 100%;"></div>
                    </div>
                </div>
            </div>

            <div class="stat-card-creative">
                <div class="stat-card-header">
                    <div class="stat-icon-creative" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"></path>
                            <line x1="7" y1="7" x2="7.01" y2="7"></line>
                        </svg>
                    </div>
                    <span class="stat-badge-small">All Time</span>
                </div>
                <div class="stat-content">
                    <h2 class="stat-number"><?php echo number_format($overall_stats['total']); ?></h2>
                    <p class="stat-label">Total Vehicles</p>
                    <div class="stat-progress">
                        <div class="progress-bar" style="background: linear-gradient(90deg, #667eea 0%, #764ba2 100%); width: 100%;"></div>
                    </div>
                </div>
            </div>

            <div class="stat-card-creative">
                <div class="stat-card-header">
                    <div class="stat-icon-creative" style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                            <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                        </svg>
                    </div>
                    <span class="stat-badge-small stat-badge-live">
                        Live
                    </span>
                </div>
                <div class="stat-content">
                    <h2 class="stat-number"><?php echo number_format($overall_stats['parked']); ?></h2>
                    <p class="stat-label">Currently Parked</p>
                    <div class="stat-progress">
                        <div class="progress-bar" style="background: linear-gradient(90deg, #f093fb 0%, #f5576c 100%); width: 100%;"></div>
                    </div>
                </div>
            </div>

            <div class="stat-card-creative">
                <div class="stat-card-header">
                    <div class="stat-icon-creative" style="background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <line x1="12" y1="1" x2="12" y2="23"></line>
                            <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
                        </svg>
                    </div>
                    <span class="stat-badge-small">Earned</span>
                </div>
                <div class="stat-content">
                    <h2 class="stat-number stat-number-medium">Rs. <?php echo number_format($overall_stats['revenue'], 2); ?></h2>
                    <p class="stat-label">Total Revenue</p>
                    <div class="stat-progress">
                        <div class="progress-bar" style="background: linear-gradient(90deg, #43e97b 0%, #38f9d7 100%); width: 100%;"></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Area Breakdown -->
        <div class="dashboard-card" style="margin-top: 40px;">
            <div class="card-header">
                <h3>
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="12" cy="12" r="10"></circle>
                        <line x1="12" y1="8" x2="12" y2="16"></line>
                        <line x1="8" y1="12" x2="16" y2="12"></line>
                    </svg>
                    Breakdown by Parking Area
                </h3>
            </div>
            <div class="card-body">
                <div class="vehicle-type-breakdown">
                    <?php 
                    $colors = [
                        ['bg' => 'linear-gradient(135deg, #f5f6fa 0%, #f5f6fa 100%)', 'bar' => '#1976D2', 'text' => '#1976D2'],
                        ['bg' => 'linear-gradient(135deg, #f5f6fa 0%, #f5f6fa 100%)', 'bar' => '#1976D2', 'text' => '#1976D2'],
                        ['bg' => 'linear-gradient(135deg, #f5f6fa 0%, #f5f6fa 100%)', 'bar' => '#1976D2', 'text' => '#1976D2'],
                        ['bg' => 'linear-gradient(135deg, #f5f6fa 0%, #f5f6fa 100%)', 'bar' => '#1976D2', 'text' => '#1976D2']
                    ];
                    $index = 0;
                    foreach ($area_stats as $stat): 
                        $percentage = $total_vehicles > 0 ? ($stat['total_count'] / $total_vehicles) * 100 : 0;
                        $color_scheme = $colors[$index % 4];
                    ?>
                    <div class="type-breakdown-item" style="background: <?php echo $color_scheme['bg']; ?>;">
                        <div class="type-breakdown-header">
                            <div class="type-breakdown-info">
                                <div class="type-breakdown-icon-wrapper">
                                    <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#000000" stroke-width="2">
                                        <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                                        <circle cx="12" cy="10" r="3"></circle>
                                    </svg>
                                </div>
                                <div class="type-breakdown-title">
                                    <h4 style=""><?php echo htmlspecialchars($stat['area_name']); ?></h4>
                                    <span class="type-breakdown-count"><?php echo number_format($stat['total_count']); ?> vehicles</span>
                                </div>
                            </div>
                            <div class="type-breakdown-percentage">
                                <?php echo number_format($percentage, 1); ?>%
                            </div>
                        </div>
                        
                        <div class="type-breakdown-bar">
                            <div class="bar-fill" style="width: <?php echo $percentage; ?>%; background: #ff9800;"></div>
                        </div>

                        <div class="type-breakdown-details">
                            <div class="detail-row">
                                <div class="detail-item">
                                    <div class="detail-icon" style="background: #667eea;">
                                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"></path>
                                            <line x1="7" y1="7" x2="7.01" y2="7"></line>
                                        </svg>
                                    </div>
                                    <div class="detail-content">
                                        <span class="detail-label">Total Parked</span>
                                        <span class="detail-value"><?php echo number_format($stat['total_count']); ?></span>
                                    </div>
                                </div>
                                <div class="detail-item">
                                    <div class="detail-icon" style="background: #f093fb;">
                                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                                            <circle cx="8.5" cy="7" r="4"></circle>
                                            <polyline points="17 11 19 13 23 9"></polyline>
                                        </svg>
                                    </div>
                                    <div class="detail-content">
                                        <span class="detail-label">Today Parked</span>
                                        <span class="detail-value"><?php echo number_format($stat['today_parked']); ?></span>
                                    </div>
                                </div>
                            </div>

                            <div class="detail-row">
                                <div class="detail-item detail-item-parked">
                                    <div class="detail-icon">
                                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                                            <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                                        </svg>
                                    </div>
                                    <div class="detail-content">
                                        <span class="detail-label">Currently Parked</span>
                                        <span class="detail-value"><?php echo number_format($stat['currently_parked']); ?></span>
                                    </div>
                                </div>
                                <div class="detail-item detail-item-checked">
                                    <div class="detail-icon">
                                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <polyline points="9 11 12 14 22 4"></polyline>
                                            <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path>
                                        </svg>
                                    </div>
                                    <div class="detail-content">
                                        <span class="detail-label">Today Checkout</span>
                                        <span class="detail-value"><?php echo number_format($stat['today_checkout']); ?></span>
                                    </div>
                                </div>
                            </div>

                            <div class="detail-row">
                                <div class="detail-item detail-item-revenue">
                                    <div class="detail-icon detail-icon-revenue">
                                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                                            <line x1="12" y1="1" x2="12" y2="23"></line>
                                            <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
                                        </svg>
                                    </div>
                                    <div class="detail-content">
                                        <span class="detail-label">Total Revenue</span>
                                        <span class="detail-value detail-value-large">Rs. <?php echo number_format($stat['total_revenue'], 2); ?></span>
                                    </div>
                                </div>
                                <div class="detail-item detail-item-revenue">
                                    <div class="detail-icon detail-icon-revenue">
                                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                                            <line x1="12" y1="1" x2="12" y2="23"></line>
                                            <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
                                        </svg>
                                    </div>
                                    <div class="detail-content">
                                        <span class="detail-label">Today Revenue</span>
                                        <span class="detail-value detail-value-large">Rs. <?php echo number_format($stat['today_revenue'], 2); ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php 
                        $index++;
                    endforeach; 
                    ?>
                </div>
            </div>
        </div>
    </div>

    <script src="script.js"></script>
</body>
</html>



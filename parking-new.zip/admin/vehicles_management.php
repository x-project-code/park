<?php
session_start();
require_once '../config.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id']) || !isset($_SESSION['is_admin'])) {
    header('Location: login.php');
    exit();
}

// Check if user_id parameter is provided
if (!isset($_GET['user_id']) || empty($_GET['user_id'])) {
    header('Location: user_breakdown.php');
    exit();
}

$selected_user_id = intval($_GET['user_id']);

$conn = getDBConnection();

// Handle AJAX request for pagination
$is_ajax = isset($_GET['ajax']) && $_GET['ajax'] == '1';
$message = '';
$message_type = '';

// Get selected user details
$user_stmt = $conn->prepare("SELECT id, username, status FROM users WHERE id = ?");
$user_stmt->bind_param("i", $selected_user_id);
$user_stmt->execute();
$user_result = $user_stmt->get_result();
$selected_user = $user_result->fetch_assoc();
$user_stmt->close();

if (!$selected_user) {
    header('Location: user_breakdown.php');
    exit();
}

// Handle CRUD Operations
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // CREATE - Add new vehicle
    if (isset($_POST['action']) && $_POST['action'] === 'create') {
        $vehicle_number = $_POST['vehicle_number'];
        $vehicle_type_id = $_POST['vehicle_type_id'];
        $area_id = $_POST['area_id'];
        $status = $_POST['status'];
        $check_in_time = $_POST['check_in_time'];
        $check_out_time = !empty($_POST['check_out_time']) ? $_POST['check_out_time'] : NULL;
        $parking_fee = $_POST['parking_fee'];

        $stmt = $conn->prepare("INSERT INTO vehicles (vehicle_number, vehicle_type_id, area_id, user_id, status, check_in_time, check_out_time, parking_fee) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("siiiissd", $vehicle_number, $vehicle_type_id, $area_id, $selected_user_id, $status, $check_in_time, $check_out_time, $parking_fee);

        if ($stmt->execute()) {
            $message = "Vehicle added successfully!";
            $message_type = "success";
        } else {
            $message = "Error adding vehicle: " . $conn->error;
            $message_type = "error";
        }
        $stmt->close();
    }

    // UPDATE - Edit existing vehicle
    if (isset($_POST['action']) && $_POST['action'] === 'update') {
        $id = $_POST['id'];
        $vehicle_number = $_POST['vehicle_number'];
        $vehicle_type_id = $_POST['vehicle_type_id'];
        $area_id = $_POST['area_id'];
        $status = $_POST['status'];
        $check_in_time = $_POST['check_in_time'];
        $check_out_time = !empty($_POST['check_out_time']) ? $_POST['check_out_time'] : NULL;
        $parking_fee = $_POST['parking_fee'];

        $stmt = $conn->prepare("UPDATE vehicles SET vehicle_number=?, vehicle_type_id=?, area_id=?, status=?, check_in_time=?, check_out_time=?, parking_fee=? WHERE id=? AND user_id=?");
        $stmt->bind_param("siiissdi", $vehicle_number, $vehicle_type_id, $area_id, $status, $check_in_time, $check_out_time, $parking_fee, $id, $selected_user_id);

        if ($stmt->execute()) {
            $message = "Vehicle updated successfully!";
            $message_type = "success";
        } else {
            $message = "Error updating vehicle: " . $conn->error;
            $message_type = "error";
        }
        $stmt->close();
    }

    // DELETE - Remove vehicle
    if (isset($_POST['action']) && $_POST['action'] === 'delete') {
        $id = $_POST['id'];

        $stmt = $conn->prepare("DELETE FROM vehicles WHERE id=? AND user_id=?");
        $stmt->bind_param("ii", $id, $selected_user_id);

        if ($stmt->execute()) {
            $message = "Vehicle deleted successfully!";
            $message_type = "success";
        } else {
            $message = "Error deleting vehicle: " . $conn->error;
            $message_type = "error";
        }
        $stmt->close();
    }
}

// Pagination settings
$records_per_page = 10;
$current_page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$offset = ($current_page - 1) * $records_per_page;

// Get total count of vehicles for this user
$count_stmt = $conn->prepare("SELECT COUNT(*) as total FROM vehicles WHERE user_id = ?");
$count_stmt->bind_param("i", $selected_user_id);
$count_stmt->execute();
$count_result = $count_stmt->get_result();
$total_records = $count_result->fetch_assoc()['total'];
$count_stmt->close();

$total_pages = ceil($total_records / $records_per_page);

// Get vehicles for this specific user with pagination
$vehicles_stmt = $conn->prepare("SELECT v.id, v.vehicle_number, v.status, v.check_in_time, v.check_out_time, v.parking_fee,
                                 vt.type_name, vt.icon_path, vt.id as vehicle_type_id,
                                 a.area_name, a.id as area_id,
                                 u.username, u.id as user_id
                                 FROM vehicles v
                                 LEFT JOIN vehicle_types vt ON v.vehicle_type_id = vt.id
                                 LEFT JOIN areas a ON v.area_id = a.id
                                 LEFT JOIN users u ON v.user_id = u.id
                                 WHERE v.user_id = ?
                                 ORDER BY v.check_in_time DESC
                                 LIMIT ? OFFSET ?");
$vehicles_stmt->bind_param("iii", $selected_user_id, $records_per_page, $offset);
$vehicles_stmt->execute();
$vehicles_result = $vehicles_stmt->get_result();

$vehicles = [];
while ($vehicle = $vehicles_result->fetch_assoc()) {
    $vehicles[] = $vehicle;
}
$vehicles_stmt->close();

// Get vehicle types for dropdown
$vehicle_types_result = $conn->query("SELECT id, type_name FROM vehicle_types ORDER BY type_name");
$vehicle_types = [];
if ($vehicle_types_result) {
    while ($type = $vehicle_types_result->fetch_assoc()) {
        $vehicle_types[] = $type;
    }
}

// Get areas for dropdown
$areas_result = $conn->query("SELECT id, area_name FROM areas ORDER BY area_name");
$areas = [];
if ($areas_result) {
    while ($area = $areas_result->fetch_assoc()) {
        $areas[] = $area;
    }
}

// Calculate statistics (from all vehicles, not just paginated)
$total_vehicles = $total_records;

$stats_stmt = $conn->prepare("SELECT 
                               SUM(CASE WHEN status = 'parked' THEN 1 ELSE 0 END) as parked_count,
                               SUM(CASE WHEN status = 'checked_out' THEN 1 ELSE 0 END) as checked_out_count,
                               COALESCE(SUM(CASE WHEN status = 'checked_out' THEN parking_fee ELSE 0 END), 0) as total_revenue
                               FROM vehicles 
                               WHERE user_id = ?");
$stats_stmt->bind_param("i", $selected_user_id);
$stats_stmt->execute();
$stats_result = $stats_stmt->get_result();
$stats = $stats_result->fetch_assoc();
$stats_stmt->close();

$parked_count = $stats['parked_count'];
$checked_out_count = $stats['checked_out_count'];
$total_revenue = $stats['total_revenue'];

// If AJAX request, return only table data
if ($is_ajax) {
    closeDBConnection($conn);
    
    $response = [
        'success' => true,
        'html' => '',
        'pagination' => '',
        'info' => ''
    ];
    
    // Generate table rows HTML
    ob_start();
    if (count($vehicles) > 0) {
        $index = $offset + 1;
        foreach ($vehicles as $vehicle) {
            $status_class = 'status-' . $vehicle['status'];
            
            // Calculate parking duration (Sri Lanka time)
            date_default_timezone_set('Asia/Colombo');
            $check_in = strtotime($vehicle['check_in_time']);
            $check_out = $vehicle['check_out_time'] ? strtotime($vehicle['check_out_time']) : time();
            $duration_seconds = $check_out - $check_in;
            
            $days = floor($duration_seconds / 86400);
            $hours = floor(($duration_seconds % 86400) / 3600);
            $minutes = floor(($duration_seconds % 3600) / 60);
            
            $duration_text = '';
            if ($days > 0) {
                $duration_text .= $days . 'd ';
            }
            if ($hours > 0 || $days > 0) {
                $duration_text .= $hours . 'h ';
            }
            $duration_text .= $minutes . 'm';
            
            ?>
            <tr>
                <td><?php echo $index; ?></td>
                <td style="font-weight: 600;">
                    <?php echo htmlspecialchars($vehicle['vehicle_number']); ?>
                </td>
                <td>
                    <img src="../<?php echo htmlspecialchars($vehicle['icon_path']); ?>"
                         alt="<?php echo htmlspecialchars($vehicle['type_name']); ?>"
                         class="vehicle-icon">
                    <?php echo htmlspecialchars($vehicle['type_name']); ?>
                </td>
                <td><?php echo htmlspecialchars($vehicle['area_name']); ?></td>
                <td><?php echo date('Y-m-d h:i A', strtotime($vehicle['check_in_time'])); ?></td>
                <td>
                    <?php echo $vehicle['check_out_time'] ? date('Y-m-d h:i A', strtotime($vehicle['check_out_time'])) : '-'; ?>
                </td>
                <td style="font-weight: 600; color: #667eea;">
                    <?php echo trim($duration_text); ?>
                </td>
                <td style="font-weight: 600; color:rgb(9, 139, 53);">
                    <?php echo number_format($vehicle['parking_fee'], 2); ?>
                </td>
                <td style="text-align: center;">
                    <span class="status-badge <?php echo $status_class; ?>">
                        <?php echo str_replace('_', ' ', $vehicle['status']); ?>
                    </span>
                </td>
            </tr>
            <?php
            $index++;
        }
    }
    $response['html'] = ob_get_clean();
    
    // Generate pagination HTML
    ob_start();
    if ($total_pages > 1) {
        ?>
        <!-- Previous Button -->
        <?php if ($current_page > 1): ?>
            <a href="#" onclick="loadPage(<?php echo $current_page - 1; ?>); return false;">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="15 18 9 12 15 6"></polyline>
                </svg>
                Prev
            </a>
        <?php else: ?>
            <span class="disabled">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="15 18 9 12 15 6"></polyline>
                </svg>
                Prev
            </span>
        <?php endif; ?>

        <!-- Page Numbers -->
        <?php
        $start_page = max(1, $current_page - 2);
        $end_page = min($total_pages, $current_page + 2);

        if ($start_page > 1) {
            echo '<a href="#" onclick="loadPage(1); return false;">1</a>';
            if ($start_page > 2) {
                echo '<span style="color: #6c757d;">...</span>';
            }
        }

        for ($i = $start_page; $i <= $end_page; $i++) {
            if ($i == $current_page) {
                echo '<span class="current">' . $i . '</span>';
            } else {
                echo '<a href="#" onclick="loadPage(' . $i . '); return false;">' . $i . '</a>';
            }
        }

        if ($end_page < $total_pages) {
            if ($end_page < $total_pages - 1) {
                echo '<span style="color: #6c757d;">...</span>';
            }
            echo '<a href="#" onclick="loadPage(' . $total_pages . '); return false;">' . $total_pages . '</a>';
        }
        ?>

        <!-- Next Button -->
        <?php if ($current_page < $total_pages): ?>
            <a href="#" onclick="loadPage(<?php echo $current_page + 1; ?>); return false;">
                Next
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="9 18 15 12 9 6"></polyline>
                </svg>
            </a>
        <?php else: ?>
            <span class="disabled">
                Next
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="9 18 15 12 9 6"></polyline>
                </svg>
            </span>
        <?php endif; ?>
        <?php
    }
    $response['pagination'] = ob_get_clean();
    
    // Generate info HTML
    $response['info'] = 'Showing ' . ($offset + 1) . ' to ' . min($offset + $records_per_page, $total_records) . ' of ' . $total_records . ' vehicles';
    
    header('Content-Type: application/json');
    echo json_encode($response);
    exit();
}

closeDBConnection($conn);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
    <title>Manage Vehicles - <?php echo htmlspecialchars($selected_user['username']); ?> - Admin Panel</title>
    <link rel="stylesheet" href="style.css">
    <?php include 'protection.php'; ?>
    <style>
        /* Mobile Responsive Table Styles */
        .table-container {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .crud-table {
            width: 100%;
            min-width: 1000px;
            border-collapse: collapse;
            background: white;
        }

        .crud-table thead {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            position: sticky;
            top: 0;
            z-index: 10;
        }

        .crud-table thead th {
            padding: 16px 12px;
            text-align: left;
            font-size: 14px;
            font-weight: 600;
            color: white;
            white-space: nowrap;
        }

        .crud-table tbody tr {
            border-bottom: 1px solid #f0f0f0;
            transition: all 0.3s ease;
        }

        .crud-table tbody tr:hover {
            background: #f8f9fa;
            transform: scale(1.01);
        }

        .crud-table tbody td {
            padding: 14px 12px;
            font-size: 13px;
            color: #2c3e50;
        }


        /* User Info Badge */
        .user-info-badge {
            display: inline-flex;
            align-items: center;
            gap: 12px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 12px 20px;
            border-radius: 12px;
            margin-bottom: 20px;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
        }

        .user-info-badge svg {
            flex-shrink: 0;
        }

        .user-info-text {
            display: flex;
            flex-direction: column;
            gap: 4px;
        }

        .user-info-text .username {
            font-size: 18px;
            font-weight: 700;
        }

        .user-info-text .status {
            font-size: 12px;
            opacity: 0.9;
        }

        /* Stats Cards */
        /* Stats Grid - Same as index.php */
        .stats-grid-creative {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 24px;
            margin-bottom: 30px;
        }

        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.6);
            backdrop-filter: blur(5px);
            animation: fadeIn 0.3s ease;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }

            to {
                opacity: 1;
            }
        }

        .modal-content {
            background: white;
            margin: 2% auto;
            padding: 30px;
            border-radius: 16px;
            width: 90%;
            max-width: 600px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
            animation: slideDown 0.3s ease;
            max-height: 90vh;
            overflow-y: auto;
        }

        @keyframes slideDown {
            from {
                transform: translateY(-50px);
                opacity: 0;
            }

            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            transition: color 0.3s;
        }

        .close:hover {
            color: #000;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #2c3e50;
            font-size: 14px;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s ease;
            box-sizing: border-box;
        }

        .form-group input:focus,
        .form-group select:focus {
            border-color: #667eea;
            outline: none;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .form-buttons {
            display: flex;
            gap: 12px;
            margin-top: 24px;
        }

        .btn-submit {
            flex: 1;
            padding: 12px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
        }

        .btn-cancel {
            flex: 1;
            padding: 12px;
            background: #6c757d;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-cancel:hover {
            background: #5a6268;
        }

        .alert {
            padding: 16px;
            border-radius: 8px;
            margin-bottom: 20px;
            animation: slideDown 0.3s ease;
        }

        .alert-success {
            background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
            color: white;
        }

        .alert-error {
            background: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
            color: white;
        }

        .status-badge {
            display: inline-block;
            padding: 6px 14px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 600;
            text-transform: capitalize;
        }

        .status-parked {
            background: #43e97b;
            color: white;
        }

        .status-checked_out {
            background: #f44336;
            color: white;
        }

        .vehicle-icon {
            width: 24px;
            height: 24px;
            vertical-align: middle;
            margin-right: 8px;
        }

        /* Pagination Styles */
        .pagination-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 30px 20px;
            gap: 20px;
            flex-wrap: wrap;
            border-top: 1px solid #f0f0f0;
        }

        .pagination {
            display: flex;
            gap: 8px;
            align-items: center;
            flex-wrap: wrap;
        }

        .pagination a,
        .pagination span {
            min-width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            padding: 0 12px;
        }

        .pagination a {
            background: white;
            color: #667eea;
            border: 2px solid #e0e0e0;
        }

        .pagination a:hover {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-color: #667eea;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
        }

        .pagination span.current {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: 2px solid #667eea;
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
        }

        .pagination .disabled {
            background: #f5f5f5;
            color: #ccc;
            border: 2px solid #e0e0e0;
            cursor: not-allowed;
            pointer-events: none;
        }

        .pagination-info {
            color: #6c757d;
            font-size: 14px;
            font-weight: 500;
        }

        /* Mobile Responsive */
        @media (max-width: 768px) {
            .modal-content {
                width: 95%;
                padding: 20px;
                margin: 5% auto;
            }

            .form-buttons {
                flex-direction: column;
            }


            .page-header {
                flex-direction: column;
                gap: 15px;
            }

            .user-info-badge {
                flex-direction: column;
                text-align: center;
            }

            .stats-grid-creative {
                grid-template-columns: 1fr;
            }

            .pagination-container {
                flex-direction: column;
                align-items: center;
                padding: 20px 10px;
                gap: 12px;
            }

            .pagination {
                justify-content: center;
                gap: 4px;
            }

            .pagination a,
            .pagination span {
                min-width: 32px;
                height: 32px;
                font-size: 12px;
                padding: 0 8px;
            }

            .pagination a svg,
            .pagination span svg {
                width: 12px;
                height: 12px;
            }

            .pagination-info {
                font-size: 12px;
            }
        }
    </style>
</head>

<body>
    <?php include 'header.php'; ?>

    <div class="container">
        <div class="page-header">
            <div>
                <h1>
                    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="vertical-align: middle; margin-right: 10px;">
                        <rect x="1" y="3" width="15" height="13"></rect>
                        <polygon points="16 8 20 8 23 11 23 16 16 16 16 8"></polygon>
                        <circle cx="5.5" cy="18.5" r="2.5"></circle>
                        <circle cx="18.5" cy="18.5" r="2.5"></circle>
                    </svg>
                    Vehicle Management
                </h1>
                <p style="margin-top: 8px; color: #6c757d;">Manage vehicles for <?php echo htmlspecialchars($selected_user['username']); ?></p>
            </div>
            <a href="user_breakdown.php" class="btn btn-secondary">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <line x1="19" y1="12" x2="5" y2="12"></line>
                    <polyline points="12 19 5 12 12 5"></polyline>
                </svg>
                Back to Users
            </a>
        </div>

        <!-- Statistics Cards with Animation - Same as index.php -->
        <div class="stats-grid-creative">
            <!-- 1. Total Vehicles -->
            <div class="stat-card-creative" data-animate="true">
                <div class="stat-card-header">
                    <div class="stat-icon-creative" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <rect x="1" y="3" width="15" height="13"></rect>
                            <polygon points="16 8 20 8 23 11 23 16 16 16 16 8"></polygon>
                            <circle cx="5.5" cy="18.5" r="2.5"></circle>
                            <circle cx="18.5" cy="18.5" r="2.5"></circle>
                        </svg>
                    </div>
                    <span class="stat-badge-small">All Vehicles</span>
                </div>
                <div class="stat-content">
                    <h2 class="stat-number" data-target="<?php echo $total_vehicles; ?>">0</h2>
                    <p class="stat-label">Total Vehicles</p>
                    <div class="stat-progress">
                        <div class="progress-bar" style="background: linear-gradient(90deg, #667eea 0%, #764ba2 100%); width: 100%;"></div>
                    </div>
                </div>
            </div>

            <!-- 2. Currently Parked -->
            <div class="stat-card-creative" data-animate="true">
                <div class="stat-card-header">
                    <div class="stat-icon-creative" style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                            <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                        </svg>
                    </div>
                    <span class="stat-badge-small stat-badge-live">
                        <span class="pulse-dot"></span>
                        Live
                    </span>
                </div>
                <div class="stat-content">
                    <h2 class="stat-number" data-target="<?php echo $parked_count; ?>">0</h2>
                    <p class="stat-label">Currently Parked</p>
                    <div class="stat-progress">
                        <div class="progress-bar" style="background: linear-gradient(90deg, #4facfe 0%, #00f2fe 100%); width: <?php echo $total_vehicles > 0 ? ($parked_count / $total_vehicles * 100) : 0; ?>%;"></div>
                    </div>
                </div>
            </div>

            <!-- 3. Checked Out -->
            <div class="stat-card-creative" data-animate="true">
                <div class="stat-card-header">
                    <div class="stat-icon-creative" style="background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polyline points="9 11 12 14 22 4"></polyline>
                            <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path>
                        </svg>
                    </div>
                    <span class="stat-badge-small">Completed</span>
                </div>
                <div class="stat-content">
                    <h2 class="stat-number" data-target="<?php echo $checked_out_count; ?>">0</h2>
                    <p class="stat-label">Checked Out</p>
                    <div class="stat-progress">
                        <div class="progress-bar" style="background: linear-gradient(90deg, #43e97b 0%, #38f9d7 100%); width: <?php echo $total_vehicles > 0 ? ($checked_out_count / $total_vehicles * 100) : 0; ?>%;"></div>
                    </div>
                </div>
            </div>

            <!-- 4. Total Revenue -->
            <div class="stat-card-creative stat-card-featured" data-animate="true">
                <div class="featured-overlay"></div>
                <div class="stat-card-header">
                    <div class="stat-icon-creative" style="background: linear-gradient(135deg, #fa709a 0%, #fee140 100%);">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <line x1="12" y1="1" x2="12" y2="23"></line>
                            <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
                        </svg>
                    </div>
                    <span class="stat-badge-premium">💰 Revenue</span>
                </div>
                <div class="stat-content">
                    <h2 class="stat-number stat-number-large">Rs. <?php echo number_format($total_revenue, 2); ?></h2>
                    <p class="stat-label">Total Revenue</p>
                </div>
            </div>
        </div>

        <?php if ($message): ?>
            <div class="alert alert-<?php echo $message_type; ?>">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>

        <!-- Vehicles Table -->
        <div class="dashboard-card">
            <div class="card-header">
                <h3>
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M4 7h16"></path>
                        <path d="M4 12h16"></path>
                        <path d="M4 17h16"></path>
                    </svg>
                    Vehicle List (<?php echo $total_records; ?>)
                </h3>
            </div>
            <div class="card-body" style="padding: 0;">
                <?php if (count($vehicles) > 0): ?>
                    <div class="table-container">
                        <table class="crud-table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Vehicle Number</th>
                                    <th>Type</th>
                                    <th>Area</th>
                                    <th>Check In</th>
                                    <th>Check Out</th>
                                    <th>Duration</th>
                                    <th>Fee (Rs.)</th>
                                    <th style="text-align: center;">Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $index = $offset + 1;
                                foreach ($vehicles as $vehicle):
                                    $status_class = 'status-' . $vehicle['status'];
                                    
                                    // Calculate parking duration (Sri Lanka time)
                                    date_default_timezone_set('Asia/Colombo');
                                    $check_in = strtotime($vehicle['check_in_time']);
                                    $check_out = $vehicle['check_out_time'] ? strtotime($vehicle['check_out_time']) : time();
                                    $duration_seconds = $check_out - $check_in;
                                    
                                    $days = floor($duration_seconds / 86400);
                                    $hours = floor(($duration_seconds % 86400) / 3600);
                                    $minutes = floor(($duration_seconds % 3600) / 60);
                                    
                                    $duration_text = '';
                                    if ($days > 0) {
                                        $duration_text .= $days . 'd ';
                                    }
                                    if ($hours > 0 || $days > 0) {
                                        $duration_text .= $hours . 'h ';
                                    }
                                    $duration_text .= $minutes . 'm';
                                ?>
                                    <tr>
                                        <td><?php echo $index; ?></td>
                                        <td style="font-weight: 600;">
                                            <?php echo htmlspecialchars($vehicle['vehicle_number']); ?>
                                        </td>
                                        <td>
                                            <img src="../<?php echo htmlspecialchars($vehicle['icon_path']); ?>"
                                                alt="<?php echo htmlspecialchars($vehicle['type_name']); ?>"
                                                class="vehicle-icon">
                                            <?php echo htmlspecialchars($vehicle['type_name']); ?>
                                        </td>
                                        <td><?php echo htmlspecialchars($vehicle['area_name']); ?></td>
                                        <td><?php echo date('Y-m-d h:i A', strtotime($vehicle['check_in_time'])); ?></td>
                                        <td>
                                            <?php echo $vehicle['check_out_time'] ? date('Y-m-d h:i A', strtotime($vehicle['check_out_time'])) : '-'; ?>
                                        </td>
                                        <td style="font-weight: 600; color: #667eea;">
                                            <?php echo trim($duration_text); ?>
                                        </td>
                                        <td style="font-weight: 600; color:rgb(9, 139, 53);">
                                            <?php echo number_format($vehicle['parking_fee'], 2); ?>
                                        </td>
                                        <td style="text-align: center;">
                                            <span class="status-badge <?php echo $status_class; ?>">
                                                <?php echo str_replace('_', ' ', $vehicle['status']); ?>
                                            </span>
                                        </td>
                                    </tr>
                                <?php
                                    $index++;
                                endforeach;
                                ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Pagination -->
                    <?php if ($total_pages > 1): ?>
                        <div class="pagination-container">
                            <div class="pagination-info" id="pagination-info">
                                Showing <?php echo $offset + 1; ?> to <?php echo min($offset + $records_per_page, $total_records); ?> of <?php echo $total_records; ?> vehicles
                            </div>
                            <div class="pagination" id="pagination-links">
                                <!-- Previous Button -->
                                <?php if ($current_page > 1): ?>
                                    <a href="#" onclick="loadPage(<?php echo $current_page - 1; ?>); return false;">
                                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <polyline points="15 18 9 12 15 6"></polyline>
                                        </svg>
                                        Prev
                                    </a>
                                <?php else: ?>
                                    <span class="disabled">
                                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <polyline points="15 18 9 12 15 6"></polyline>
                                        </svg>
                                        Prev
                                    </span>
                                <?php endif; ?>

                                <!-- Page Numbers -->
                                <?php
                                $start_page = max(1, $current_page - 2);
                                $end_page = min($total_pages, $current_page + 2);

                                if ($start_page > 1) {
                                    echo '<a href="#" onclick="loadPage(1); return false;">1</a>';
                                    if ($start_page > 2) {
                                        echo '<span style="color: #6c757d;">...</span>';
                                    }
                                }

                                for ($i = $start_page; $i <= $end_page; $i++) {
                                    if ($i == $current_page) {
                                        echo '<span class="current">' . $i . '</span>';
                                    } else {
                                        echo '<a href="#" onclick="loadPage(' . $i . '); return false;">' . $i . '</a>';
                                    }
                                }

                                if ($end_page < $total_pages) {
                                    if ($end_page < $total_pages - 1) {
                                        echo '<span style="color: #6c757d;">...</span>';
                                    }
                                    echo '<a href="#" onclick="loadPage(' . $total_pages . '); return false;">' . $total_pages . '</a>';
                                }
                                ?>

                                <!-- Next Button -->
                                <?php if ($current_page < $total_pages): ?>
                                    <a href="#" onclick="loadPage(<?php echo $current_page + 1; ?>); return false;">
                                        Next
                                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <polyline points="9 18 15 12 9 6"></polyline>
                                        </svg>
                                    </a>
                                <?php else: ?>
                                    <span class="disabled">
                                        Next
                                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <polyline points="9 18 15 12 9 6"></polyline>
                                        </svg>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endif; ?>

                <?php else: ?>
                    <div style="padding: 60px 20px; text-align: center; color: #6c757d;">
                        <svg width="80" height="80" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="opacity: 0.3; margin-bottom: 20px;">
                            <rect x="1" y="3" width="15" height="13"></rect>
                            <polygon points="16 8 20 8 23 11 23 16 16 16 16 8"></polygon>
                            <circle cx="5.5" cy="18.5" r="2.5"></circle>
                            <circle cx="18.5" cy="18.5" r="2.5"></circle>
                        </svg>
                        <h3 style="margin: 0 0 10px 0; color: #2c3e50;">No vehicles found</h3>
                        <p style="margin: 0;">This user has no vehicles yet.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Create Modal -->
    <div id="createModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal('createModal')">&times;</span>
            <h2 style="margin-bottom: 20px; color: #2c3e50;">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="vertical-align: middle; margin-right: 8px;">
                    <line x1="12" y1="5" x2="12" y2="19"></line>
                    <line x1="5" y1="12" x2="19" y2="12"></line>
                </svg>
                Add New Vehicle for <?php echo htmlspecialchars($selected_user['username']); ?>
            </h2>
            <form method="POST">
                <input type="hidden" name="action" value="create">

                <div class="form-group">
                    <label>Vehicle Number *</label>
                    <input type="text" name="vehicle_number" required placeholder="e.g., ABC-1234">
                </div>

                <div class="form-group">
                    <label>Vehicle Type *</label>
                    <select name="vehicle_type_id" required>
                        <option value="">Select Type</option>
                        <?php foreach ($vehicle_types as $type): ?>
                            <option value="<?php echo $type['id']; ?>">
                                <?php echo htmlspecialchars($type['type_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label>Area *</label>
                    <select name="area_id" required>
                        <option value=""></option>Select Area</option>
                        <?php foreach ($areas as $area): ?>
                            <option value="<?php echo $area['id']; ?>">
                                <?php echo htmlspecialchars($area['area_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label>Status *</label>
                    <select name="status" required>
                        <option value="parked">Parked</option>
                        <option value="checked_out">Checked Out</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Check In Time *</label>
                    <input type="datetime-local" name="check_in_time" required>
                </div>

                <div class="form-group"></div>
                    <label>Check Out Time</label>
                    <input type="datetime-local" name="check_out_time">
                </div>

                <div class="form-group">
                    <label>Parking Fee (Rs.) *</label>
                    <input type="number" step="0.01" name="parking_fee" required placeholder="0.00">
                </div>

                <div class="form-buttons">
                    <button type="submit" class="btn-submit">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="vertical-align: middle;">
                            <polyline points="20 6 9 17 4 12"></polyline>
                        </svg>
                        Create Vehicle
                    </button>
                    <button type="button" class="btn-cancel" onclick="closeModal('createModal')">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Edit Modal -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal('editModal')">&times;</span>
            <h2 style="margin-bottom: 20px; color: #2c3e50;">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="vertical-align: middle; margin-right: 8px;">
                    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                    <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                </svg>
                Edit Vehicle
            </h2>
            <form method="POST" id="editForm">
                <input type="hidden" name="action" value="update">
                <input type="hidden" name="id" id="edit_id">

                <div class="form-group">
                    <label>Vehicle Number *</label>
                    <input type="text" name="vehicle_number" id="edit_vehicle_number" required>
                </div>

                <div class="form-group">
                    <label>Vehicle Type *</label>
                    <select name="vehicle_type_id" id="edit_vehicle_type_id" required>
                        <option value="">Select Type</option>
                        <?php foreach ($vehicle_types as $type): ?>
                            <option value="<?php echo $type['id']; ?>">
                                <?php echo htmlspecialchars($type['type_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label>Area *</label>
                    <select name="area_id" id="edit_area_id" required>
                        <option value="">Select Area</option>
                        <?php foreach ($areas as $area): ?>
                            <option value="<?php echo $area['id']; ?>">
                                <?php echo htmlspecialchars($area['area_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label>Status *</label>
                    <select name="status" id="edit_status" required>
                        <option value="parked">Parked</option>
                        <option value="checked_out">Checked Out</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Check In Time *</label>
                    <input type="datetime-local" name="check_in_time" id="edit_check_in_time" required>
                </div>

                <div class="form-group">
                    <label>Check Out Time</label>
                    <input type="datetime-local" name="check_out_time" id="edit_check_out_time">
                </div>

                <div class="form-group">
                    <label>Parking Fee (Rs.) *</label>
                    <input type="number" step="0.01" name="parking_fee" id="edit_parking_fee" required>
                </div>

                <div class="form-buttons">
                    <button type="submit" class="btn-submit">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="vertical-align: middle;">
                            <polyline points="20 6 9 17 4 12"></polyline>
                        </svg>
                        Update Vehicle
                    </button>
                    <button type="button" class="btn-cancel" onclick="closeModal('editModal')">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <script src="script.js"></script>
    <script>
        function openCreateModal() {
            document.getElementById('createModal').style.display = 'block';
        }

        function openEditModal(vehicle) {
            document.getElementById('edit_id').value = vehicle.id;
            document.getElementById('edit_vehicle_number').value = vehicle.vehicle_number;
            document.getElementById('edit_vehicle_type_id').value = vehicle.vehicle_type_id;
            document.getElementById('edit_area_id').value = vehicle.area_id;
            document.getElementById('edit_status').value = vehicle.status;

            // Format datetime for input
            if (vehicle.check_in_time) {
                const checkInDate = new Date(vehicle.check_in_time);
                document.getElementById('edit_check_in_time').value = formatDateTimeLocal(checkInDate);
            }

            if (vehicle.check_out_time) {
                const checkOutDate = new Date(vehicle.check_out_time);
                document.getElementById('edit_check_out_time').value = formatDateTimeLocal(checkOutDate);
            } else {
                document.getElementById('edit_check_out_time').value = '';
            }

            document.getElementById('edit_parking_fee').value = vehicle.parking_fee;
            document.getElementById('editModal').style.display = 'block';
        }

        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }

        function formatDateTimeLocal(date) {
            const year = date.getFullYear();
            const month = String(date.getMonth() + 1).padStart(2, '0');
            const day = String(date.getDate()).padStart(2, '0');
            const hours = String(date.getHours()).padStart(2, '0');
            const minutes = String(date.getMinutes()).padStart(2, '0');
            return `${year}-${month}-${day}T${hours}:${minutes}`;
        }

        // Close modal when clicking outside
        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.style.display = 'none';
            }
        }

        // Auto-hide alert after 5 seconds
        setTimeout(function() {
            const alert = document.querySelector('.alert');
            if (alert) {
                alert.style.animation = 'fadeOut 0.5s ease';
                setTimeout(() => alert.remove(), 500);
            }
        }, 5000);

        // Stat Card Animations - Same as index.php
        document.addEventListener('DOMContentLoaded', function() {
            // Animate numbers
            const statNumbers = document.querySelectorAll('.stat-number[data-target]');

            statNumbers.forEach(stat => {
                const target = parseInt(stat.getAttribute('data-target'));
                const duration = 2000;
                const increment = target / (duration / 16);
                let current = 0;

                const updateNumber = () => {
                    current += increment;
                    if (current < target) {
                        stat.textContent = Math.floor(current);
                        requestAnimationFrame(updateNumber);
                    } else {
                        stat.textContent = target;
                    }
                };

                // Start animation when element is in view
                const observer = new IntersectionObserver((entries) => {
                    entries.forEach(entry => {
                        if (entry.isIntersecting) {
                            updateNumber();
                            observer.unobserve(entry.target);
                        }
                    });
                }, {
                    threshold: 0.1
                });

                observer.observe(stat.closest('.stat-card-creative'));
            });

            // Animate progress bars
            const progressBars = document.querySelectorAll('.progress-bar');
            const progressObserver = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.style.width = entry.target.style.width || '100%';
                        progressObserver.unobserve(entry.target);
                    }
                });
            }, {
                threshold: 0.1
            });

            progressBars.forEach(bar => {
                const width = bar.style.width;
                bar.style.width = '0';
                setTimeout(() => {
                    bar.style.width = width;
                    bar.style.transition = 'width 1.5s ease-out';
                }, 100);
            });
        });

        // AJAX Pagination Function
        function loadPage(page) {
            const userId = <?php echo $selected_user_id; ?>;
            const tableBody = document.querySelector('.crud-table tbody');
            const paginationLinks = document.getElementById('pagination-links');
            const paginationInfo = document.getElementById('pagination-info');
            
            // Add loading state
            tableBody.style.opacity = '0.5';
            tableBody.style.pointerEvents = 'none';
            
            // Fetch data via AJAX
            fetch(`?user_id=${userId}&page=${page}&ajax=1`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Update table body
                        tableBody.innerHTML = data.html;
                        
                        // Update pagination links
                        if (paginationLinks) {
                            paginationLinks.innerHTML = data.pagination;
                        }
                        
                        // Update info text
                        if (paginationInfo) {
                            paginationInfo.textContent = data.info;
                        }
                        
                        // Restore table state
                        tableBody.style.opacity = '1';
                        tableBody.style.pointerEvents = 'auto';
                        
                        // Smooth scroll to table
                        document.querySelector('.crud-table').scrollIntoView({ 
                            behavior: 'smooth', 
                            block: 'start' 
                        });
                    }
                })
                .catch(error => {
                    console.error('Error loading page:', error);
                    tableBody.style.opacity = '1';
                    tableBody.style.pointerEvents = 'auto';
                });
        }
    </script>

    <style>
        @keyframes fadeOut {
            from {
                opacity: 1;
            }

            to {
                opacity: 0;
            }
        }
    </style>
</body>

</html>